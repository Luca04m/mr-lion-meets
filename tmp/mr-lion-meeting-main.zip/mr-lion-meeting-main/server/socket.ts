import { Server as SocketIOServer } from "socket.io";
import type { Server as HttpServer } from "http";

let io: SocketIOServer | null = null;

// Track online users: socketId -> { name, joinedAt }
const onlineUsers = new Map<string, { name: string; joinedAt: number }>();

export function getIo(): SocketIOServer | null {
  return io;
}

export function setupSocket(server: HttpServer) {
  io = new SocketIOServer(server, {
    path: "/api/socket",
    cors: {
      origin: "*",
      methods: ["GET", "POST"],
    },
    transports: ["websocket", "polling"],
  });

  io.on("connection", (socket) => {
    console.log(`[Socket] Client connected: ${socket.id}`);

    // User identifies themselves
    socket.on("user:join", (data: { name: string }) => {
      onlineUsers.set(socket.id, { name: data.name, joinedAt: Date.now() });
      broadcastPresence();
    });

    // User leaves
    socket.on("disconnect", () => {
      onlineUsers.delete(socket.id);
      broadcastPresence();
      console.log(`[Socket] Client disconnected: ${socket.id}`);
    });

    // Typing indicator (user is editing a task)
    socket.on("user:editing", (data: { taskId: number; userName: string }) => {
      socket.broadcast.emit("user:editing", data);
    });

    socket.on("user:stopEditing", (data: { taskId: number; userName: string }) => {
      socket.broadcast.emit("user:stopEditing", data);
    });
  });

  function broadcastPresence() {
    const users = Array.from(onlineUsers.values()).map((u) => u.name);
    // Deduplicate names
    const uniqueUsers = Array.from(new Set(users));
    io?.emit("presence:update", { users: uniqueUsers, count: uniqueUsers.length });
  }

  return io;
}
