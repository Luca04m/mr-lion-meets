import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createTestContext(): TrpcContext {
  const user: AuthenticatedUser = {
    id: 1,
    openId: "test-user",
    email: "test@example.com",
    name: "Test User",
    loginMethod: "manus",
    role: "admin",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  return {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: () => {},
    } as TrpcContext["res"],
  };
}

function createPublicContext(): TrpcContext {
  return {
    user: null,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: () => {},
    } as TrpcContext["res"],
  };
}

describe("tasks API", () => {
  it("lists all tasks from the database", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const tasks = await caller.tasks.list();

    expect(Array.isArray(tasks)).toBe(true);
    expect(tasks.length).toBeGreaterThan(0);
    // Check first task has expected shape
    const first = tasks[0];
    expect(first).toHaveProperty("id");
    expect(first).toHaveProperty("title");
    expect(first).toHaveProperty("priority");
    expect(first).toHaveProperty("status");
    expect(first).toHaveProperty("responsible");
    expect(first).toHaveProperty("area");
  });

  it("gets a single task by id", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    // Get the first task ID dynamically
    const allTasks = await caller.tasks.list();
    const firstId = allTasks[0].id;

    const task = await caller.tasks.get({ id: firstId });

    expect(task).not.toBeNull();
    expect(task!.id).toBe(firstId);
    expect(task!.title).toBeTruthy();
  });

  it("updates task status and logs activity", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    // Get the first task ID dynamically
    const allTasks = await caller.tasks.list();
    const firstId = allTasks[0].id;

    // Get current status
    const before = await caller.tasks.get({ id: firstId });
    const originalStatus = before!.status;

    // Update to em-andamento
    const result = await caller.tasks.updateStatus({
      id: firstId,
      status: "em-andamento",
      userName: "Test",
    });

    expect(result).toHaveProperty("success", true);

    // Verify status changed
    const after = await caller.tasks.get({ id: firstId });
    expect(after!.status).toBe("em-andamento");

    // Restore original status
    await caller.tasks.updateStatus({
      id: firstId,
      status: originalStatus as "pendente" | "em-andamento" | "concluida" | "atrasada",
      userName: "Test",
    });
  });

  it("updates task notes", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const testNote = "Nota de teste " + Date.now();

    // Get the first task ID dynamically
    const allTasks = await caller.tasks.list();
    const firstId = allTasks[0].id;

    const result = await caller.tasks.updateNotes({
      id: firstId,
      notes: testNote,
      userName: "Test",
    });

    expect(result).toHaveProperty("success", true);

    const after = await caller.tasks.get({ id: firstId });
    expect(after!.notes).toBe(testNote);

    // Clean up
    await caller.tasks.updateNotes({
      id: firstId,
      notes: "",
      userName: "Test",
    });
  });

  it("creates and deletes a task", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    // Create
    const created = await caller.tasks.create({
      title: "Tarefa de teste vitest",
      detail: "Criada automaticamente pelo teste",
      responsible: ["Test"],

      priority: "baixa",
      area: "comercial",
      userName: "Test",
    });

    expect(created).toHaveProperty("id");
    expect(typeof created.id).toBe("number");

    // Verify it exists
    const fetched = await caller.tasks.get({ id: created.id });
    expect(fetched).not.toBeNull();
    expect(fetched!.title).toBe("Tarefa de teste vitest");

    // Delete
    const deleted = await caller.tasks.delete({
      id: created.id,
      userName: "Test",
    });

    expect(deleted).toHaveProperty("success", true);
  });
});

describe("activity API", () => {
  it("returns recent activity", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const activities = await caller.activity.recent({ limit: 10 });

    expect(Array.isArray(activities)).toBe(true);
    // After the status update test above, there should be at least some activity
  });
});
