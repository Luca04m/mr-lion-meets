import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";
import {
  getAllTasks,
  getTaskById,
  createTask,
  updateTask,
  deleteTask,
  logActivity,
  getRecentActivity,
  getActivityForTask,
  getAllMeetings,
  createMeeting,
  deleteMeeting,
} from "./db";
import { storagePut } from "./storage";
import { getIo } from "./socket";

// Helper to emit real-time events
function emitTaskUpdate(event: string, data: unknown) {
  try {
    const io = getIo();
    if (io) io.emit(event, data);
  } catch {
    // socket not initialized yet, skip
  }
}

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  tasks: router({
    list: publicProcedure.query(async () => {
      return getAllTasks();
    }),

    get: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        return getTaskById(input.id);
      }),

    updateStatus: publicProcedure
      .input(z.object({
        id: z.number(),
        status: z.enum(["pendente", "em-andamento", "concluida", "atrasada"]),
        userName: z.string().min(1),
      }))
      .mutation(async ({ input }) => {
        const task = await getTaskById(input.id);
        if (!task) throw new Error("Task not found");

        const oldStatus = task.status;
        await updateTask(input.id, { status: input.status });

        await logActivity({
          taskId: input.id,
          taskTitle: task.title,
          userName: input.userName,
          action: "status_change",
          oldValue: oldStatus,
          newValue: input.status,
        });

        emitTaskUpdate("task:updated", {
          id: input.id,
          field: "status",
          value: input.status,
          userName: input.userName,
        });

        return { success: true };
      }),

    updateNotes: publicProcedure
      .input(z.object({
        id: z.number(),
        notes: z.string(),
        userName: z.string().min(1),
      }))
      .mutation(async ({ input }) => {
        const task = await getTaskById(input.id);
        if (!task) throw new Error("Task not found");

        await updateTask(input.id, { notes: input.notes });

        await logActivity({
          taskId: input.id,
          taskTitle: task.title,
          userName: input.userName,
          action: "notes_update",
          oldValue: task.notes || "",
          newValue: input.notes,
        });

        emitTaskUpdate("task:updated", {
          id: input.id,
          field: "notes",
          value: input.notes,
          userName: input.userName,
        });

        return { success: true };
      }),

    create: publicProcedure
      .input(z.object({
        title: z.string().min(1),
        detail: z.string().default(""),
        responsible: z.array(z.string()),

        priority: z.enum(["alta", "media", "baixa"]).default("media"),
        area: z.string(),
        status: z.enum(["pendente", "em-andamento", "concluida", "atrasada"]).default("pendente"),
        dependencies: z.array(z.number()).default([]),
        decision: z.string().nullable().default(null),
        userName: z.string().min(1),
      }))
      .mutation(async ({ input }) => {
        const { userName, ...taskData } = input;
        const newId = await createTask({
          ...taskData,
          notes: "",
          createdBy: userName,
          isOriginal: 0,
        });

        await logActivity({
          taskId: newId,
          taskTitle: input.title,
          userName,
          action: "task_created",
          oldValue: null,
          newValue: input.title,
        });

        emitTaskUpdate("task:created", { id: newId, userName });

        return { id: newId };
      }),

    update: publicProcedure
      .input(z.object({
        id: z.number(),
        title: z.string().optional(),
        detail: z.string().optional(),
        responsible: z.array(z.string()).optional(),

        priority: z.enum(["alta", "media", "baixa"]).optional(),
        area: z.string().optional(),
        status: z.enum(["pendente", "em-andamento", "concluida", "atrasada"]).optional(),
        dependencies: z.array(z.number()).optional(),
        decision: z.string().nullable().optional(),
        userName: z.string().min(1),
      }))
      .mutation(async ({ input }) => {
        const { id, userName, ...updates } = input;
        const task = await getTaskById(id);
        if (!task) throw new Error("Task not found");

        await updateTask(id, updates);

        // Log what changed
        const changedFields = Object.keys(updates).filter(k => k !== "userName");
        for (const field of changedFields) {
          await logActivity({
            taskId: id,
            taskTitle: task.title,
            userName,
            action: `field_update:${field}`,
            oldValue: String((task as any)[field] ?? ""),
            newValue: String((updates as any)[field] ?? ""),
          });
        }

        emitTaskUpdate("task:updated", { id, fields: changedFields, userName });

        return { success: true };
      }),

    delete: publicProcedure
      .input(z.object({
        id: z.number(),
        userName: z.string().min(1),
      }))
      .mutation(async ({ input }) => {
        const task = await getTaskById(input.id);
        if (!task) throw new Error("Task not found");

        await deleteTask(input.id);

        await logActivity({
          taskId: input.id,
          taskTitle: task.title,
          userName: input.userName,
          action: "task_deleted",
          oldValue: task.title,
          newValue: null,
        });

        emitTaskUpdate("task:deleted", { id: input.id, userName: input.userName });

        return { success: true };
      }),
  }),

  activity: router({
    recent: publicProcedure
      .input(z.object({ limit: z.number().default(50) }).optional())
      .query(async ({ input }) => {
        return getRecentActivity(input?.limit ?? 50);
      }),

    forTask: publicProcedure
      .input(z.object({ taskId: z.number() }))
      .query(async ({ input }) => {
        return getActivityForTask(input.taskId);
      }),
  }),

  meetings: router({
    list: publicProcedure.query(async () => {
      return getAllMeetings();
    }),

    create: publicProcedure
      .input(z.object({
        title: z.string().min(1),
        meetingDate: z.string().min(1),
        fileType: z.enum(["pauta", "resumo", "outro"]).default("pauta"),
        fileName: z.string().min(1),
        fileBase64: z.string().min(1),
        contentType: z.string().default("application/pdf"),
        uploadedBy: z.string().default("Sistema"),
      }))
      .mutation(async ({ input }) => {
        // Upload to S3
        const buffer = Buffer.from(input.fileBase64, "base64");
        const suffix = Math.random().toString(36).substring(2, 8);
        const fileKey = `meetings/${input.meetingDate}-${suffix}-${input.fileName}`;
        const { url } = await storagePut(fileKey, buffer, input.contentType);

        const id = await createMeeting({
          title: input.title,
          meetingDate: input.meetingDate,
          fileType: input.fileType,
          fileName: input.fileName,
          fileUrl: url,
          fileKey,
          uploadedBy: input.uploadedBy,
        });

        return { id, url };
      }),

    delete: publicProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await deleteMeeting(input.id);
        return { success: true };
      }),
  }),
});

export type AppRouter = typeof appRouter;
