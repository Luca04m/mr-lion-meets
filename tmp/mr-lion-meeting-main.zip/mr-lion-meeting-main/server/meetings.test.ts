import { describe, expect, it, vi, beforeEach } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

// Mock storagePut to avoid real S3 calls
vi.mock("./storage", () => ({
  storagePut: vi.fn().mockResolvedValue({ url: "https://s3.example.com/test.pdf", key: "meetings/test.pdf" }),
}));

// Mock socket to avoid real socket calls
vi.mock("./socket", () => ({
  getIo: vi.fn().mockReturnValue(null),
}));

function createPublicContext(): TrpcContext {
  return {
    user: null,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: vi.fn(),
    } as unknown as TrpcContext["res"],
  };
}

describe("meetings router", () => {
  let caller: ReturnType<typeof appRouter.createCaller>;

  beforeEach(() => {
    caller = appRouter.createCaller(createPublicContext());
  });

  it("meetings.list returns an array", async () => {
    const result = await caller.meetings.list();
    expect(Array.isArray(result)).toBe(true);
  });

  it("meetings.create uploads a document and returns id + url", async () => {
    const result = await caller.meetings.create({
      title: "Test Meeting Pauta",
      meetingDate: "2026-02-19",
      fileType: "pauta",
      fileName: "test-pauta.pdf",
      fileBase64: Buffer.from("fake pdf content").toString("base64"),
      contentType: "application/pdf",
      uploadedBy: "Luca",
    });

    expect(result).toHaveProperty("id");
    expect(result).toHaveProperty("url");
    expect(typeof result.id).toBe("number");
    expect(typeof result.url).toBe("string");
  });

  it("meetings.delete removes a meeting", async () => {
    // First create one
    const created = await caller.meetings.create({
      title: "To Delete",
      meetingDate: "2026-02-19",
      fileType: "resumo",
      fileName: "delete-me.pdf",
      fileBase64: Buffer.from("content").toString("base64"),
      contentType: "application/pdf",
      uploadedBy: "João",
    });

    const result = await caller.meetings.delete({ id: created.id });
    expect(result).toEqual({ success: true });
  });
});

describe("tasks router", () => {
  let caller: ReturnType<typeof appRouter.createCaller>;

  beforeEach(() => {
    caller = appRouter.createCaller(createPublicContext());
  });

  it("tasks.list returns an array of tasks", async () => {
    const result = await caller.tasks.list();
    expect(Array.isArray(result)).toBe(true);
    expect(result.length).toBeGreaterThan(0);
  });

  it("tasks.create creates a new task and returns id", async () => {
    const result = await caller.tasks.create({
      title: "Test Task",
      detail: "Test detail",
      responsible: ["Luca"],
      priority: "media",
      area: "comercial",
      userName: "TestUser",
    });
    expect(result).toHaveProperty("id");
    expect(typeof result.id).toBe("number");
  });

  it("tasks.update can change task status", async () => {
    const tasks = await caller.tasks.list();
    const task = tasks[0];
    if (!task) return;

    const result = await caller.tasks.update({
      id: task.id,
      status: "concluida",
      userName: "TestUser",
    });
    expect(result).toEqual({ success: true });

    // Verify the change
    const updated = await caller.tasks.get({ id: task.id });
    expect(updated?.status).toBe("concluida");

    // Revert
    await caller.tasks.update({
      id: task.id,
      status: task.status as "pendente" | "em-andamento" | "concluida" | "atrasada",
      userName: "TestUser",
    });
  });

  it("tasks.update can edit title and responsible", async () => {
    const created = await caller.tasks.create({
      title: "Edit Me",
      detail: "Original detail",
      responsible: ["Luca"],
      priority: "baixa",
      area: "comercial",
      userName: "TestUser",
    });

    const result = await caller.tasks.update({
      id: created.id,
      title: "Edited Title",
      responsible: ["Luca", "João"],
      userName: "TestUser",
    });
    expect(result).toEqual({ success: true });

    const updated = await caller.tasks.get({ id: created.id });
    expect(updated?.title).toBe("Edited Title");

    // Clean up
    await caller.tasks.delete({ id: created.id, userName: "TestUser" });
  });
});
