import "dotenv/config";
import mysql from "mysql2/promise";

const DATABASE_URL = process.env.DATABASE_URL;
if (!DATABASE_URL) {
  console.error("DATABASE_URL is required");
  process.exit(1);
}

const tasks = [
  { id: 1, title: "Avaliar gateways de pagamento", detail: "João questionou a taxa alta do Mercado Pago. Avaliar Nuvem Pago (taxa menor, mas sem proteção contra cartão clonado) e outras opções. Luca enviará PDF comparativo.", responsible: ["João"], deadline: "Até 20/02", deadlineDate: "2026-02-20", priority: "alta", area: "nuvemshop", status: "pendente", dependencies: [], notes: "", decision: "D2" },
  { id: 2, title: "Resolver questão do CNPJ", detail: "Sem o CNPJ resolvido, João não consegue avançar com o site. Luhan vai ligar para o MD junto com João hoje mesmo para acelerar.", responsible: ["Luhan", "João"], deadline: "Imediato (13/02)", deadlineDate: "2026-02-13", priority: "alta", area: "nuvemshop", status: "pendente", dependencies: [], notes: "", decision: "D2" },
  { id: 3, title: "Testar bot de suporte Nuvemshop", detail: "Bot já configurado na Nuvemshop, mas nunca testado. Precisa validar antes de ativar.", responsible: ["Luca"], deadline: "Até 20/02", deadlineDate: "2026-02-20", priority: "alta", area: "nuvemshop", status: "pendente", dependencies: [], notes: "", decision: null },
  { id: 4, title: "Testar integração Bling + Nuvemshop", detail: "Bling já integrado, mas precisa de testes. Verificar se puxa pedidos corretamente, se o status é atualizado e se a baixa de estoque funciona.", responsible: ["Luca"], deadline: "Até 20/02", deadlineDate: "2026-02-20", priority: "alta", area: "nuvemshop", status: "pendente", dependencies: [], notes: "", decision: "D2" },
  { id: 5, title: "Avaliar questão dos kits/combos na Nuvemshop", detail: "Na Nuvemshop, kits precisam ser cadastrados como produto único. Isso já deu problema com o Bling no passado. Precisa testar antes de subir.", responsible: ["João", "Luca"], deadline: "Antes de subir o site", deadlineDate: "2026-02-28", priority: "alta", area: "nuvemshop", status: "pendente", dependencies: [4], notes: "", decision: "D2" },
  { id: 6, title: "Configurar domínio Nuvemshop", detail: "Só será feito após o gateway estar resolvido, para não derrubar o site atual.", responsible: ["Luca"], deadline: "Após gateway resolvido", deadlineDate: null, priority: "alta", area: "nuvemshop", status: "pendente", dependencies: [1], notes: "", decision: "D2" },
  { id: 7, title: "Kit Carnaval — 3 garrafas a R$299", detail: "3 garrafas mistas por R$299 (+ 5% no crédito). Preço definido na reunião por João.", responsible: ["João", "Luca"], deadline: "Antes do Carnaval", deadlineDate: "2026-02-14", priority: "alta", area: "carnaval", status: "pendente", dependencies: [], notes: "", decision: "D1" },
  { id: 8, title: "Criativos e Stories de Carnaval", detail: "Luca fará criativos para Stories orgânicos durante o Carnaval e deixará rodando no tráfego pago.", responsible: ["Luca"], deadline: "Antes do Carnaval", deadlineDate: "2026-02-14", priority: "alta", area: "carnaval", status: "pendente", dependencies: [], notes: "", decision: "D1" },
  { id: 9, title: "Enviar press-kits para o Rio", detail: "João vai enviar os kits. Não precisa esperar os cartões impressos.", responsible: ["João"], deadline: "Imediato", deadlineDate: "2026-02-14", priority: "media", area: "press-kit", status: "pendente", dependencies: [], notes: "", decision: "D6" },
  { id: 10, title: "Imprimir material gráfico no Rio", detail: "Luhan recebe o material e manda imprimir em gráfica local para manter o padrão.", responsible: ["Luhan"], deadline: "Após receber do João", deadlineDate: null, priority: "media", area: "press-kit", status: "pendente", dependencies: [9], notes: "", decision: "D6" },
  { id: 11, title: "Enviar amostras para Orochi", detail: "Já foram despachadas. Aguardando chegada no Rio.", responsible: ["João"], deadline: "Já enviado", deadlineDate: "2026-02-13", priority: "alta", area: "orochi", status: "concluida", dependencies: [], notes: "", decision: null },
  { id: 12, title: "Levar amostras ao Orochi pessoalmente", detail: "Assim que chegar, é prioridade levar pessoalmente. Orochi é imprevisível — pode marcar hoje e ser amanhã.", responsible: ["Luhan"], deadline: "Semana que vem", deadlineDate: "2026-02-20", priority: "alta", area: "orochi", status: "pendente", dependencies: [11], notes: "", decision: null },
  { id: 13, title: "Enviar apresentação da marca no grupo", detail: "Luca vai reenviar a apresentação da marca (12 páginas) no grupo para Luhan avaliar.", responsible: ["Luca"], deadline: "Imediato", deadlineDate: "2026-02-13", priority: "media", area: "orochi", status: "pendente", dependencies: [], notes: "", decision: null },
  { id: 14, title: "Luhan avaliar apresentação e sugerir ajustes", detail: "Luhan avalia se está no caminho certo e sugere ajustes antes de mostrar ao Orochi.", responsible: ["Luhan"], deadline: "Após receber", deadlineDate: null, priority: "media", area: "orochi", status: "pendente", dependencies: [13], notes: "", decision: null },
  { id: 15, title: "Estruturar programa Mr. Lion Nation (treinamento)", detail: "João vai montar o conteúdo vídeo a vídeo. Ideia: vídeos pontuais, bem editados, sem enrolação.", responsible: ["João"], deadline: "Até 28/02", deadlineDate: "2026-02-28", priority: "alta", area: "nation", status: "pendente", dependencies: [], notes: "", decision: "D3" },
  { id: 16, title: "Definir premiações e ranking do Nation", detail: "Premiação final de ~R$30.000 + ranking mensal com prêmios menores. Sistema de pontos acumulados.", responsible: ["João"], deadline: "Até 28/02", deadlineDate: "2026-02-28", priority: "alta", area: "nation", status: "pendente", dependencies: [], notes: "", decision: "D3" },
  { id: 17, title: "Estratégia de aproximação Carlos Prates", detail: "MD precisa ir à casa dele em SP, passar 1-2 dias, construir relacionamento.", responsible: ["Luhan"], deadline: "Fevereiro/Março", deadlineDate: "2026-03-15", priority: "media", area: "carlos-prates", status: "pendente", dependencies: [], notes: "", decision: null },
  { id: 18, title: "Tentar visita ao Carlos Prates em SP (~5 de Março)", detail: "João estará em SP por volta de 5 de Março. Tentar alinhar uma data.", responsible: ["João", "Luhan"], deadline: "Início de Março", deadlineDate: "2026-03-05", priority: "media", area: "carlos-prates", status: "pendente", dependencies: [], notes: "", decision: null },
  { id: 19, title: "Enviar amostras para Carlos Prates", detail: "Luhan pode adiantar enviando amostras para Carlos Prates em Fevereiro.", responsible: ["Luhan"], deadline: "Fevereiro", deadlineDate: "2026-02-28", priority: "media", area: "carlos-prates", status: "pendente", dependencies: [], notes: "", decision: null },
  { id: 20, title: "Confirmar cobrança por mensagem no HighLevel", detail: "Luca precisa confirmar se o HighLevel cobra por mensagem enviada ou por todas as mensagens.", responsible: ["Luca"], deadline: "Até 20/02", deadlineDate: "2026-02-20", priority: "media", area: "comercial", status: "pendente", dependencies: [], notes: "", decision: null },
  { id: 21, title: "Trocar ideia com contato do João (bot SDR)", detail: "João tem um contato que faz bots SDR. Trocar uma ideia para avaliar se terceiriza ou continua no HighLevel.", responsible: ["João"], deadline: "Até 20/02", deadlineDate: "2026-02-20", priority: "media", area: "comercial", status: "pendente", dependencies: [], notes: "", decision: null },
  { id: 22, title: "Marcar reunião com Vinícius (processos)", detail: "Luhan vai ligar hoje para o Vinícius e marcar uma reunião para introduzir o Luca e discutir processos.", responsible: ["Luhan"], deadline: "Imediato (ligar hoje)", deadlineDate: "2026-02-13", priority: "alta", area: "comercial", status: "pendente", dependencies: [], notes: "", decision: "D5" },
  { id: 23, title: "Pedro — Documento diagnóstico comercial", detail: "Pedro vai documentar: como está o processo, o que tem testado, o que está dando certo/errado, padrões observados.", responsible: ["Pedro"], deadline: "Até próxima reunião", deadlineDate: "2026-02-28", priority: "alta", area: "comercial", status: "pendente", dependencies: [], notes: "", decision: "D5" },
  { id: 24, title: "Pedro — Mensagem padrão de pré-cadastro PJ", detail: "Pedro já começou a montar uma mensagem de pré-cadastro para coletar dados do lead PJ na conversa inicial.", responsible: ["Pedro"], deadline: "Imediato", deadlineDate: "2026-02-14", priority: "media", area: "comercial", status: "pendente", dependencies: [], notes: "", decision: "D10" },
  { id: 25, title: "Atualizar documento Kit PDV com novas ideias", detail: "Incorporar novas sugestões: logo luminosa, totem tamanho real do MD, placa de madeira iluminada. Organizar por níveis.", responsible: ["Luca", "Guilherme"], deadline: "Até 28/02", deadlineDate: "2026-02-28", priority: "media", area: "kit-pdv", status: "pendente", dependencies: [26], notes: "", decision: null },
  { id: 26, title: "Pedro — Enviar referência de placa de madeira", detail: "Pedro viu numa destilaria e vai procurar imagem e material para compartilhar no grupo.", responsible: ["Pedro"], deadline: "Imediato", deadlineDate: "2026-02-14", priority: "baixa", area: "kit-pdv", status: "pendente", dependencies: [], notes: "", decision: null },
  { id: 27, title: "Garrafa nova + Rebranding", detail: "Luca vai desenvolver após resolver as questões básicas. O rebranding vem junto com a garrafa.", responsible: ["Luca"], deadline: "Após resolver Nuvemshop", deadlineDate: null, priority: "media", area: "garrafa-nova", status: "pendente", dependencies: [1, 4, 6], notes: "", decision: "D9" },
  { id: 28, title: "RTD — Definir sabor e começar composição", detail: "Começar a definir agora. Validação em BH em Outubro. Lançamento final em Dezembro para pegar verão + Carnaval.", responsible: ["João", "Guilherme"], deadline: "Até Julho", deadlineDate: "2026-07-31", priority: "media", area: "rtd", status: "pendente", dependencies: [], notes: "", decision: "D8" },
  { id: 29, title: "RTD — Enviar amostras para MD", detail: "Começar a enviar amostras para o MD ir provando e dando feedback.", responsible: ["João"], deadline: "Início do processo", deadlineDate: "2026-04-30", priority: "media", area: "rtd", status: "pendente", dependencies: [28], notes: "", decision: "D8" },
  { id: 30, title: "Luhan — Orçamento de ensaio fotográfico no Rio", detail: "Fotos de produto com elementos visuais de whisky. Fotos no Rio para aproveitar com MD. Vídeos em BH (mais barato).", responsible: ["Luhan"], deadline: "Até 20/02", deadlineDate: "2026-02-20", priority: "alta", area: "conteudo", status: "pendente", dependencies: [], notes: "", decision: "D7" },
  { id: 31, title: "João — Pesquisar fornecedor de copos", detail: "Demanda reprimida — clientes sempre perguntam por copos. Nem que seja um copinho simples para começar.", responsible: ["João"], deadline: "Até 28/02", deadlineDate: "2026-02-28", priority: "media", area: "produtos", status: "pendente", dependencies: [], notes: "", decision: null },
  { id: 32, title: "João — Pesquisar garrafa 375ml e kit de 3", detail: "Kit de 3 garrafas de 375ml para presente. Guilherme sugeriu caixa com alça. João vai olhar com André.", responsible: ["João"], deadline: "Até 28/02", deadlineDate: "2026-02-28", priority: "media", area: "produtos", status: "pendente", dependencies: [], notes: "", decision: null },
  { id: 33, title: "Compartilhar link do painel de reunião no grupo", detail: "Luca vai compartilhar o link do painel interativo da reunião no grupo do WhatsApp.", responsible: ["Luca"], deadline: "Imediato", deadlineDate: "2026-02-13", priority: "baixa", area: "comercial", status: "pendente", dependencies: [], notes: "", decision: null },
  { id: 34, title: "Avaliar funil de leads na Nuvemshop", detail: "Separar quem só visitou o site de quem foi até o carrinho, para qualificar leads frios vs. quentes.", responsible: ["Luca"], deadline: "Até 28/02", deadlineDate: "2026-02-28", priority: "media", area: "nuvemshop", status: "pendente", dependencies: [], notes: "", decision: null },
  { id: 35, title: "Testar integração Melhor Envio / Nuvem Envio", detail: "Melhor Envio já instalado mas nunca testado. Nuvem Envio também habilitado e parece boa opção.", responsible: ["Luca"], deadline: "Até 20/02", deadlineDate: "2026-02-20", priority: "alta", area: "nuvemshop", status: "pendente", dependencies: [], notes: "", decision: null },
  { id: 36, title: "Planejar ação presencial RTD na Copa", detail: "Distribuir 1.000-5.000 latinhas presencialmente durante a Copa, com cadastro no site via QR Code.", responsible: ["Guilherme", "João"], deadline: "Planejamento até Maio", deadlineDate: "2026-05-31", priority: "media", area: "rtd", status: "pendente", dependencies: [28], notes: "", decision: "D8" },
  { id: 37, title: "Sondar a Toy sobre campanha Dia da Mulher (8/03)", detail: "Luhan sugeriu a Toy como embaixadora/cara da campanha de Dia da Mulher. Sondagem de disponibilidade e interesse.", responsible: ["Luhan"], deadline: "Até 20/02", deadlineDate: "2026-02-20", priority: "alta", area: "marketing", status: "pendente", dependencies: [], notes: "", decision: null },
  { id: 38, title: "Testar cálculo de frete para múltiplas unidades", detail: "O frete bugava no site antigo quando o cliente comprava mais de uma unidade ou kits. Bug crítico de conversão.", responsible: ["João", "Luca"], deadline: "Antes de subir o site", deadlineDate: "2026-02-28", priority: "alta", area: "nuvemshop", status: "pendente", dependencies: [], notes: "", decision: "D2" },
  { id: 39, title: "Avaliar relançamento do Black Honey durante a Copa", detail: "Guilherme identificou demanda reprimida e sugeriu relançar durante a Copa. Avaliar viabilidade.", responsible: ["João", "Guilherme"], deadline: "Decisão até Abril", deadlineDate: "2026-04-30", priority: "media", area: "produtos", status: "pendente", dependencies: [], notes: "", decision: null },
];

async function seed() {
  const conn = await mysql.createConnection(DATABASE_URL);
  
  // Check if tasks already exist
  const [rows] = await conn.execute("SELECT COUNT(*) as cnt FROM tasks");
  if (rows[0].cnt > 0) {
    console.log(`Tasks table already has ${rows[0].cnt} rows. Skipping seed.`);
    await conn.end();
    return;
  }

  console.log("Seeding 39 tasks...");
  
  for (const t of tasks) {
    await conn.execute(
      `INSERT INTO tasks (title, detail, responsible, deadline, deadlineDate, priority, area, status, dependencies, notes, decision, createdBy, isOriginal) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Sistema', 1)`,
      [
        t.title,
        t.detail,
        JSON.stringify(t.responsible),
        t.deadline,
        t.deadlineDate,
        t.priority,
        t.area,
        t.status,
        JSON.stringify(t.dependencies),
        t.notes,
        t.decision,
      ]
    );
  }

  console.log("✓ 39 tasks seeded successfully");
  await conn.end();
}

seed().catch(err => {
  console.error("Seed failed:", err);
  process.exit(1);
});
