import mysql from 'mysql2/promise';
import { config } from 'dotenv';
config();

const conn = await mysql.createConnection(process.env.DATABASE_URL);

const tasks = [
  // Luca
  { number: 1, title: 'Configurar Delivery Direto (PDV, gestão de pedidos, estoque)', area: 'Delivery', priority: 'alta', owner: 'Luca', context: 'Prazo: 27/02. Configurar sistema completo de delivery incluindo PDV, gestão de pedidos e controle de estoque.' },
  { number: 2, title: 'Verificar integração Nuvemshop com ponto de venda/retirada', area: 'Nuvemshop', priority: 'alta', owner: 'Luca', context: 'Verificar se a Nuvemshop suporta integração com ponto de venda físico e retirada em loja.' },
  { number: 3, title: 'Cadastrar Mercado Livre + Amazon', area: 'Nuvemshop', priority: 'alta', owner: 'Luca', context: 'Prazo: 27/02. Cadastrar a marca nos marketplaces Mercado Livre e Amazon.' },
  { number: 4, title: 'Mandar scripts para Guilherme (Bot SDR)', area: 'Comercial', priority: 'alta', owner: 'Luca', context: 'Enviar os scripts de vendas para Guilherme configurar o Bot SDR.' },
  { number: 5, title: 'Enviar direcional de quantidade de fotos para Luhan', area: 'Marketing', priority: 'media', owner: 'Luca', context: 'Definir e enviar para Luhan a quantidade e tipo de fotos necessárias para o ensaio fotográfico.' },
  { number: 6, title: 'Chamar Pedro individualmente para alinhar diagnóstico comercial', area: 'Comercial', priority: 'alta', owner: 'Luca', context: 'Reunião individual com Pedro para alinhar o diagnóstico comercial e próximos passos.' },
  { number: 7, title: 'Mandar ideias de sabores RTD para João por escrito', area: 'RTD', priority: 'media', owner: 'Luca', context: 'Esta semana. João pediu para todos enviarem ideias de sabores para o RTD por escrito.' },
  { number: 8, title: 'Pesquisar composição do drink "of Miami"', area: 'RTD', priority: 'media', owner: 'Luca', context: 'Guilherme pediu explicitamente. Pesquisar: água de coco + xarope + suco de limão + melancia.' },

  // João
  { number: 9, title: 'Repassar dados para Luca (Nuvem Pago)', area: 'Nuvemshop', priority: 'alta', owner: 'João', context: 'Antes de 25/02. Repassar os dados necessários para configuração do Nuvem Pago.' },
  { number: 10, title: 'Assinar Delivery Direto', area: 'Delivery', priority: 'alta', owner: 'João', context: 'Assinar a plataforma Delivery Direto para iniciar configuração.' },
  { number: 11, title: 'Reavaliar estrutura delivery (contratar alguém ou não)', area: 'Delivery', priority: 'alta', owner: 'João', context: 'Decidir se contrata alguém dedicado para operação de delivery ou se mantém estrutura atual.' },
  { number: 12, title: 'Reunião Vinícius — 20/02 às 15h', area: 'Comercial', priority: 'alta', owner: 'João', context: 'Reunião sobre CRM com Vinícius no dia 20/02 às 15h. Luhan também participa.' },
  { number: 13, title: 'Fazer amostras RTD — aguardar ideias de sabores', area: 'RTD', priority: 'media', owner: 'João', context: 'Produzir amostras do RTD após receber ideias de sabores de toda a equipe por escrito.' },
  { number: 14, title: 'Pagar assinatura Google Play / Apple Store', area: 'Delivery', priority: 'alta', owner: 'João', context: 'Necessário para publicar o app do Delivery Direto nas lojas de aplicativos.' },
  { number: 15, title: 'Identificar 1 pessoa de confiança para piloto do Nation', area: 'Mr. Lion Nation', priority: 'alta', owner: 'João', context: 'Próxima semana. Encontrar uma pessoa de confiança para ser o primeiro piloto do programa Nation.' },

  // Luhan
  { number: 16, title: 'Mandar mensagem para Ângelo hoje para marcar café esta semana', area: 'Delivery', priority: 'alta', owner: 'Luhan', context: 'Contatar Ângelo (Degusto) hoje para agendar café esta semana.' },
  { number: 17, title: 'Café com Ângelo (Degusto): logística delivery Rio, estoque, app', area: 'Delivery', priority: 'alta', owner: 'Luhan', context: 'Confirmar logística de delivery no Rio, organização de estoque e uso do aplicativo com Ângelo da Degusto.' },
  { number: 18, title: 'Pedir orçamento ensaio fotográfico Rio', area: 'Marketing', priority: 'alta', owner: 'Luhan', context: 'Orçamento para: fotos 3 produtos + vídeo 3 produtos + vídeo só do Blend.' },
  { number: 19, title: 'Reunião Vinícius — 20/02 às 15h', area: 'Comercial', priority: 'alta', owner: 'Luhan', context: 'Reunião sobre CRM com Vinícius no dia 20/02 às 15h. João também participa.' },
  { number: 20, title: 'Sondar Tóia para ação Dia da Mulher (8/03)', area: 'Marketing', priority: 'alta', owner: 'Luhan', context: 'MD em recesso até segunda. Sondar a Tóia sobre possível ação para o Dia da Mulher em 8/03.' },
  { number: 21, title: 'Marcar reunião com Guilherme (Orochi) quando amostras chegarem', area: 'Collabs', priority: 'media', owner: 'Luhan', context: 'Agendar reunião com Guilherme do Orochi assim que as amostras da garrafa chegarem.' },
  { number: 22, title: 'Mandar ideias de sabores RTD para João por escrito', area: 'RTD', priority: 'media', owner: 'Luhan', context: 'Esta semana. João pediu para todos enviarem ideias de sabores para o RTD por escrito.' },

  // Pedro
  { number: 23, title: 'Fazer documento de diagnóstico comercial', area: 'Comercial', priority: 'alta', owner: 'Pedro', context: 'Documentar: o que testa, padrões de dúvida dos leads, objeções encontradas e sugestões de melhoria.' },
  { number: 24, title: 'Exportar histórico de conversas de qualificação do WhatsApp', area: 'Comercial', priority: 'alta', owner: 'Pedro', context: 'Exportar conversas para alimentar o Bot SDR com dados reais de qualificação.' },
  { number: 25, title: 'Reunião individual com Luca (hoje/amanhã)', area: 'Comercial', priority: 'alta', owner: 'Pedro', context: 'Alinhar diagnóstico comercial e próximos passos com Luca.' },
  { number: 26, title: 'Mandar ideias de sabores RTD para João por escrito', area: 'RTD', priority: 'media', owner: 'Pedro', context: 'Esta semana. João pediu para todos enviarem ideias de sabores para o RTD por escrito.' },

  // Guilherme
  { number: 27, title: 'Desenvolver documento Kit PDV (PDV físico por nível + Benefícios)', area: 'Kit PDV', priority: 'alta', owner: 'Guilherme', context: 'Separar PDV físico (por nível) e Benefícios (vídeo MD, visita MD, degustação) em documento estruturado.' },
  { number: 28, title: 'Mandar documento Kit PDV no grupo — hoje', area: 'Kit PDV', priority: 'alta', owner: 'Guilherme', context: 'Enviar o documento finalizado do Kit PDV no grupo hoje.' },
  { number: 29, title: 'Mandar ideias de sabores RTD para João por escrito', area: 'RTD', priority: 'media', owner: 'Guilherme', context: 'Esta semana. João pediu para todos enviarem ideias de sabores para o RTD por escrito.' },
  { number: 30, title: 'Definição da comunicação do lançamento Delivery — com Luca', area: 'Delivery', priority: 'alta', owner: 'Guilherme', context: 'Trabalhar com Luca na definição da comunicação visual e estratégia de lançamento do Delivery.' },
];

for (const t of tasks) {
  await conn.execute(
    `INSERT INTO tasks (title, detail, responsible, priority, area, status, notes, isOriginal)
     VALUES (?, ?, ?, ?, ?, 'pendente', '', 1)`,
    [t.title, t.context, JSON.stringify([t.owner]), t.priority, t.area]
  );
  console.log(`✓ #${String(t.number).padStart(2, '0')} ${t.title}`);
}

console.log(`\nTotal: ${tasks.length} tarefas inseridas.`);
await conn.end();
