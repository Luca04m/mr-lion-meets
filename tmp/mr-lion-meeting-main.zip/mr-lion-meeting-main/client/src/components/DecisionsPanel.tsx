import { X, CheckCircle2, ParkingCircle, Copy } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import type { DecisionRecord, ParkedItem } from "@/hooks/useMeetingStore";
import { toast } from "sonner";

interface DecisionsPanelProps {
  decisions: DecisionRecord[];
  parkedItems: ParkedItem[];
  onRemoveDecision: (index: number) => void;
  onRemoveParkedItem: (index: number) => void;
}

function buildExportText(decisions: DecisionRecord[], parkedItems: ParkedItem[]): string {
  let text = `📋 DECISÕES — Reunião Mr. Lion — 13/02/2026\n\n`;

  if (decisions.length > 0) {
    decisions.forEach((d) => {
      text += `✅ [${d.topicId}] ${d.topicTitle}: ${d.text}\n`;
    });
  } else {
    text += `(Nenhuma decisão registrada)\n`;
  }

  text += `\n🅿️ ESTACIONAMENTO:\n`;
  if (parkedItems.length > 0) {
    parkedItems.forEach((p) => {
      text += `- ${p.topicTitle}${p.reason ? ` (${p.reason})` : ""}\n`;
    });
  } else {
    text += `(Nenhum item estacionado)\n`;
  }

  return text;
}

export function DecisionsPanel({
  decisions,
  parkedItems,
  onRemoveDecision,
  onRemoveParkedItem,
}: DecisionsPanelProps) {
  const handleExport = async () => {
    const text = buildExportText(decisions, parkedItems);
    try {
      await navigator.clipboard.writeText(text);
      toast.success("Copiado para a área de transferência!");
    } catch {
      const textarea = document.createElement("textarea");
      textarea.value = text;
      textarea.style.position = "fixed";
      textarea.style.opacity = "0";
      document.body.appendChild(textarea);
      textarea.select();
      document.execCommand("copy");
      document.body.removeChild(textarea);
      toast.success("Copiado para a área de transferência!");
    }
  };

  return (
    <aside
      className="w-80 shrink-0 border-l border-border flex flex-col"
      style={{ backgroundColor: "var(--color-surface)" }}
    >
      <ScrollArea className="flex-1">
        {/* Decisions section */}
        <div className="p-4 border-b border-border">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4" style={{ color: "var(--color-phase-green)" }} />
              <span className="text-xs font-mono tracking-wider uppercase text-muted-foreground font-semibold">
                Decisões Registradas
              </span>
              {decisions.length > 0 && (
                <span
                  className="text-[10px] font-mono font-bold px-1.5 py-0.5 rounded-full"
                  style={{ backgroundColor: "var(--color-gold)", color: "var(--background)" }}
                >
                  {decisions.length}
                </span>
              )}
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={handleExport}
              className="h-7 px-2 text-[10px] font-mono text-muted-foreground hover:text-foreground"
              title="Exportar decisões"
            >
              <Copy className="w-3 h-3 mr-1" />
              Exportar
            </Button>
          </div>

          {decisions.length === 0 ? (
            <p className="text-xs text-muted-foreground italic py-2">
              Nenhuma decisão registrada ainda.
            </p>
          ) : (
            <div className="space-y-2">
              {decisions.map((d, i) => (
                <div
                  key={i}
                  className="group flex items-start gap-2 p-2.5 rounded-md"
                  style={{ backgroundColor: "var(--color-surface-elevated)" }}
                >
                  <div className="flex-1 min-w-0">
                    <span
                      className="text-[10px] font-mono px-1 py-0.5 rounded"
                      style={{ backgroundColor: "var(--color-gold)", color: "var(--background)" }}
                    >
                      {d.topicId}
                    </span>
                    <p className="text-xs text-foreground mt-1 leading-relaxed">{d.text}</p>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => onRemoveDecision(i)}
                    className="h-5 w-5 p-0 opacity-0 group-hover:opacity-100 transition-opacity shrink-0"
                  >
                    <X className="w-3 h-3 text-muted-foreground" />
                  </Button>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Parked items section */}
        <div className="p-4">
          <div className="flex items-center gap-2 mb-3">
            <ParkingCircle className="w-4 h-4" style={{ color: "var(--color-phase-yellow)" }} />
            <span className="text-xs font-mono tracking-wider uppercase text-muted-foreground font-semibold">
              Estacionamento
            </span>
            {parkedItems.length > 0 && (
              <span className="text-[10px] font-mono font-bold px-1.5 py-0.5 rounded-full bg-yellow-500/20 text-yellow-400">
                {parkedItems.length}
              </span>
            )}
          </div>

          {parkedItems.length === 0 ? (
            <p className="text-xs text-muted-foreground italic py-2">
              Nenhum item estacionado.
            </p>
          ) : (
            <div className="space-y-2">
              {parkedItems.map((p, i) => (
                <div
                  key={i}
                  className="group flex items-start gap-2 p-2.5 rounded-md"
                  style={{ backgroundColor: "var(--color-surface-elevated)" }}
                >
                  <div className="flex-1 min-w-0">
                    <span className="text-xs font-semibold text-foreground">{p.topicTitle}</span>
                    {p.reason && (
                      <p className="text-[10px] text-muted-foreground mt-0.5">{p.reason}</p>
                    )}
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => onRemoveParkedItem(i)}
                    className="h-5 w-5 p-0 opacity-0 group-hover:opacity-100 transition-opacity shrink-0"
                  >
                    <X className="w-3 h-3 text-muted-foreground" />
                  </Button>
                </div>
              ))}
            </div>
          )}
        </div>
      </ScrollArea>
    </aside>
  );
}
