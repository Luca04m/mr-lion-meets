import { meetingBlocks, allTopics, PHASE_CONFIG, type TopicStatus } from "@/lib/meetingData";
import { formatTime } from "@/lib/utils-timer";
import { CheckCircle2, ParkingCircle, Circle } from "lucide-react";
import { ScrollArea } from "@/components/ui/scroll-area";

interface TopicSidebarProps {
  activeTopicIndex: number;
  topicStatuses: Record<string, TopicStatus>;
  topicElapsed: Record<string, number>;
  onGoToTopic: (index: number) => void;
}

function StatusIcon({ status }: { status: TopicStatus }) {
  switch (status) {
    case "completed":
      return <CheckCircle2 className="w-3.5 h-3.5" style={{ color: "var(--color-phase-green)" }} />;
    case "parked":
      return <ParkingCircle className="w-3.5 h-3.5" style={{ color: "var(--color-phase-yellow)" }} />;
    case "active":
      return (
        <div
          className="w-3 h-3 rounded-full glow-pulse"
          style={{ backgroundColor: "var(--color-gold)" }}
        />
      );
    default:
      return <Circle className="w-3.5 h-3.5 text-muted-foreground/40" />;
  }
}

export function TopicSidebar({
  activeTopicIndex,
  topicStatuses,
  topicElapsed,
  onGoToTopic,
}: TopicSidebarProps) {
  let globalIndex = 0;

  return (
    <aside
      className="w-72 shrink-0 border-r border-border flex flex-col"
      style={{ backgroundColor: "var(--color-surface)" }}
    >
      <div className="px-4 py-3 border-b border-border">
        <span className="text-xs font-mono tracking-wider uppercase text-muted-foreground">
          Tópicos da Reunião
        </span>
      </div>
      <ScrollArea className="flex-1">
        <div className="p-2 space-y-1">
          {meetingBlocks.map((block) => {
            const blockStartIndex = globalIndex;
            return (
              <div key={block.id} className="mb-2">
                {/* Block header */}
                <div className="flex items-center justify-between px-3 py-1.5 mb-0.5">
                  <span className="text-[10px] font-mono tracking-wider uppercase text-muted-foreground font-semibold">
                    {block.title}
                  </span>
                  <span className="text-[10px] font-mono text-muted-foreground">
                    {block.timeMinutes}m
                  </span>
                </div>

                {/* Topics */}
                {block.topics.map((topic) => {
                  const idx = blockStartIndex + block.topics.indexOf(topic);
                  const isActive = idx === activeTopicIndex;
                  const status = topicStatuses[topic.id] || "waiting";
                  const elapsed = topicElapsed[topic.id] || 0;
                  const phaseConfig = PHASE_CONFIG[topic.phase];
                  const actualIdx = allTopics.findIndex((t) => t.id === topic.id);

                  globalIndex++;

                  return (
                    <button
                      key={topic.id}
                      onClick={() => onGoToTopic(actualIdx)}
                      className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-md text-left transition-all duration-200 ${
                        isActive
                          ? "ring-1"
                          : "hover:bg-accent/50"
                      }`}
                      style={
                        isActive
                          ? {
                              backgroundColor: "var(--color-surface-elevated)",
                              boxShadow: "inset 0 0 0 1px var(--color-gold)",
                            }
                          : undefined
                      }
                    >
                      {/* Phase indicator bar */}
                      <div
                        className="w-0.5 h-8 rounded-full shrink-0"
                        style={{ backgroundColor: phaseConfig.color }}
                      />

                      <StatusIcon status={status} />

                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-1.5">
                          <span className="text-[10px] font-mono font-semibold" style={{ color: "var(--color-gold-dim)" }}>
                            {topic.number}
                          </span>
                          <span
                            className={`text-xs truncate ${
                              isActive
                                ? "text-foreground font-semibold"
                                : topic.priority === "baixa"
                                ? "text-muted-foreground"
                                : "text-foreground/80"
                            }`}
                          >
                            {topic.title}
                          </span>
                        </div>
                        <div className="flex items-center gap-2 mt-0.5">
                          {topic.timeMinutes > 0 ? (
                            <span className="text-[10px] font-mono text-muted-foreground">
                              {topic.timeMinutes}m
                            </span>
                          ) : (
                            <span className="text-[10px] font-mono text-muted-foreground/50">
                              s/ tempo
                            </span>
                          )}
                          {elapsed > 0 && (
                            <span
                              className={`text-[10px] font-mono ${
                                elapsed > topic.timeMinutes * 60 ? "text-destructive" : "text-muted-foreground"
                              }`}
                            >
                              {formatTime(elapsed)}
                            </span>
                          )}
                        </div>
                      </div>
                    </button>
                  );
                })}
              </div>
            );
          })}
        </div>
      </ScrollArea>
    </aside>
  );
}
