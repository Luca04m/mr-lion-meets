import { Button } from "@/components/ui/button";
import { Play, Clock, Users, Target, ClipboardList } from "lucide-react";
import { Link } from "wouter";
import { meetingBlocks, TOTAL_MEETING_MINUTES, allTopics, PARTICIPANTS } from "@/lib/meetingData";
import { motion } from "framer-motion";

interface StartScreenProps {
  onStart: () => void;
}

export function StartScreen({ onStart }: StartScreenProps) {
  return (
    <div className="h-screen flex items-center justify-center bg-background relative overflow-hidden">
      {/* Subtle grid background */}
      <div
        className="absolute inset-0 opacity-5"
        style={{
          backgroundImage: `linear-gradient(rgba(212,168,67,0.3) 1px, transparent 1px), linear-gradient(90deg, rgba(212,168,67,0.3) 1px, transparent 1px)`,
          backgroundSize: "60px 60px",
        }}
      />

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, ease: "easeOut" }}
        className="relative z-10 text-center max-w-2xl px-6"
      >
        {/* Logo / Title */}
        <div className="mb-2">
          <span className="text-sm font-mono tracking-[0.3em] uppercase text-muted-foreground">
            Painel de Reunião
          </span>
        </div>
        <h1 className="text-5xl font-bold tracking-tight mb-2" style={{ color: "var(--color-gold)" }}>
          Mr. Lion
        </h1>
        <p className="text-muted-foreground text-lg mb-10">
          13 de Fevereiro de 2026
        </p>

        {/* Stats row */}
        <div className="flex justify-center gap-8 mb-10">
          <div className="flex items-center gap-2 text-muted-foreground">
            <Clock className="w-4 h-4" style={{ color: "var(--color-gold)" }} />
            <span className="text-sm">{TOTAL_MEETING_MINUTES} min</span>
          </div>
          <div className="flex items-center gap-2 text-muted-foreground">
            <Target className="w-4 h-4" style={{ color: "var(--color-gold)" }} />
            <span className="text-sm">{allTopics.length} tópicos</span>
          </div>
          <div className="flex items-center gap-2 text-muted-foreground">
            <Users className="w-4 h-4" style={{ color: "var(--color-gold)" }} />
            <span className="text-sm">{PARTICIPANTS.join(", ")}</span>
          </div>
        </div>

        {/* Blocks overview */}
        <div className="mb-10 space-y-2">
          {meetingBlocks.map((block) => (
            <div
              key={block.id}
              className="flex items-center justify-between px-4 py-2.5 rounded-md"
              style={{ backgroundColor: "var(--color-surface)" }}
            >
              <div className="flex items-center gap-3">
                <span
                  className="text-xs font-mono font-semibold w-5 h-5 flex items-center justify-center rounded"
                  style={{
                    backgroundColor: "var(--color-gold)",
                    color: "var(--background)",
                  }}
                >
                  {block.order + 1}
                </span>
                <span className="text-sm text-foreground">{block.title}</span>
              </div>
              <span className="text-xs font-mono text-muted-foreground">
                {block.timeMinutes} min
              </span>
            </div>
          ))}
        </div>

        {/* Buttons */}
        <div className="flex flex-col items-center gap-4">
          <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
            <Button
              onClick={onStart}
              size="lg"
              className="px-10 py-6 text-lg font-semibold rounded-lg glow-pulse"
              style={{
                backgroundColor: "var(--color-gold)",
                color: "var(--background)",
              }}
            >
              <Play className="w-5 h-5 mr-2" />
              Iniciar Reunião
            </Button>
          </motion.div>
          <Link href="/tarefas">
            <span className="flex items-center gap-2 text-sm text-muted-foreground hover:text-gold transition-colors cursor-pointer">
              <ClipboardList size={16} />
              Ver Gestão de Tarefas
            </span>
          </Link>
        </div>
      </motion.div>
    </div>
  );
}
