import { useState } from "react";
import { Button } from "@/components/ui/button";
import { ChevronLeft, ChevronRight, Plus, ParkingCircle, Link2, AlertTriangle, Calendar } from "lucide-react";
import { type Topic, PHASE_CONFIG, allTopics, INTRO_POINTS, IMPORTANT_DATES, TRANSVERSAL_DATES, NUVEMSHOP_PENDENCIAS, PONTOS_DECISORIOS } from "@/lib/meetingData";
import { DependencyMap } from "@/components/DependencyMap";
import { formatTime, getTimerClass, getProgressColor } from "@/lib/utils-timer";
import { motion, AnimatePresence } from "framer-motion";

interface ActiveTopicPanelProps {
  topic: Topic;
  topicElapsed: number;
  topicIndex: number;
  onNext: () => void;
  onPrev: () => void;
  onAddDecision: (topicId: string, topicTitle: string, text: string) => void;
  onParkItem: (topicId: string, topicTitle: string, reason: string) => void;
}

export function ActiveTopicPanel({
  topic,
  topicElapsed,
  topicIndex,
  onNext,
  onPrev,
  onAddDecision,
  onParkItem,
}: ActiveTopicPanelProps) {
  const [decisionInput, setDecisionInput] = useState("");
  const [parkReason, setParkReason] = useState("");
  const [showParkInput, setShowParkInput] = useState(false);

  if (!topic) return null;

  const phaseConfig = PHASE_CONFIG[topic.phase];
  const budgetSeconds = topic.timeMinutes * 60;
  const progress = Math.min((topicElapsed / budgetSeconds) * 100, 100);
  const timerClass = getTimerClass(topicElapsed, topic.timeMinutes);
  const progressColor = getProgressColor(topicElapsed, topic.timeMinutes);
  const isOverBudget = topicElapsed > budgetSeconds;

  const handleAddDecision = () => {
    if (decisionInput.trim()) {
      onAddDecision(topic.id, topic.title, decisionInput.trim());
      setDecisionInput("");
    }
  };

  const handlePark = () => {
    onParkItem(topic.id, topic.title, parkReason.trim() || "Sem motivo especificado");
    setParkReason("");
    setShowParkInput(false);
  };

  return (
    <main className="flex-1 flex flex-col overflow-hidden">
      {/* Navigation bar */}
      <div className="flex items-center justify-between px-6 py-2 border-b border-border">
        <Button
          variant="ghost"
          size="sm"
          onClick={onPrev}
          disabled={topicIndex === 0}
          className="text-xs"
        >
          <ChevronLeft className="w-4 h-4 mr-1" />
          Anterior
        </Button>
        <span className="text-xs font-mono text-muted-foreground">
          {topic.parentBlock}
        </span>
        <Button
          variant="ghost"
          size="sm"
          onClick={onNext}
          disabled={topicIndex === allTopics.length - 1}
          className="text-xs"
        >
          Próximo
          <ChevronRight className="w-4 h-4 ml-1" />
        </Button>
      </div>

      {/* Content area */}
      <div className="flex-1 overflow-y-auto px-8 py-6">
        <AnimatePresence mode="wait">
          <motion.div
            key={topic.id}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.2 }}
          >
            {/* Topic header */}
            <div className="flex items-start justify-between mb-6">
              <div>
                <div className="flex items-center gap-3 mb-2">
                  <span
                    className="text-sm font-mono font-bold px-2 py-0.5 rounded"
                    style={{ backgroundColor: "var(--color-gold)", color: "var(--background)" }}
                  >
                    {topic.number}
                  </span>
                  <span
                    className="text-xs font-mono px-2 py-0.5 rounded"
                    style={{ backgroundColor: phaseConfig.color + "22", color: phaseConfig.color }}
                  >
                    {phaseConfig.emoji} {phaseConfig.label}
                  </span>
                  <span
                    className={`text-xs font-mono px-2 py-0.5 rounded ${
                      topic.priority === "alta"
                        ? "bg-destructive/15 text-destructive"
                        : topic.priority === "media"
                        ? "bg-yellow-500/15 text-yellow-400"
                        : "bg-muted text-muted-foreground"
                    }`}
                  >
                    Prioridade {topic.priority.charAt(0).toUpperCase() + topic.priority.slice(1)}
                  </span>
                </div>
                <h2 className="text-2xl font-bold text-foreground">{topic.title}</h2>
                <p className="text-sm text-muted-foreground mt-1">{topic.priorityJustification}</p>
              </div>

              {/* Timer */}
              <div className="text-right shrink-0 ml-6">
                <div
                  className={`font-mono text-4xl font-bold tracking-tight ${timerClass}`}
                  style={!timerClass ? { color: "var(--color-gold)" } : undefined}
                >
                  {formatTime(topicElapsed)}
                </div>
                <div className="text-xs font-mono text-muted-foreground mt-1">
                  de {formatTime(budgetSeconds)}
                  {isOverBudget && (
                    <span className="text-destructive ml-2 font-semibold">
                      +{formatTime(topicElapsed - budgetSeconds)}
                    </span>
                  )}
                </div>
                {/* Mini progress */}
                <div className="w-32 h-1 rounded-full mt-2 ml-auto" style={{ backgroundColor: "var(--color-surface)" }}>
                  <div
                    className="h-full rounded-full transition-all duration-1000"
                    style={{ width: `${progress}%`, backgroundColor: progressColor }}
                  />
                </div>
              </div>
            </div>

            {/* Intro points — only for Panorama Geral */}
            {topic.id === "0a" && (
              <div
                className="rounded-lg p-5 mb-5"
                style={{ backgroundColor: "var(--color-surface)", border: "1px solid var(--color-phase-red)44" }}
              >
                <h3 className="text-xs font-mono tracking-wider uppercase mb-3 flex items-center gap-1.5" style={{ color: "var(--color-phase-red)" }}>
                  <AlertTriangle className="w-3.5 h-3.5" />
                  Pontos Críticos a Endereçar
                </h3>
                <ul className="space-y-2">
                  {INTRO_POINTS.map((point, i) => (
                    <li key={i} className="flex items-start gap-2 text-sm text-foreground">
                      <span className="text-muted-foreground font-mono text-xs mt-0.5 shrink-0">{String(i + 1).padStart(2, "0")}</span>
                      <span className="leading-relaxed">{point}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {/* Nuvemshop Pendencias — only for topic 1a */}
            {topic.id === "1a" && (
              <div
                className="rounded-lg p-5 mb-5"
                style={{ backgroundColor: "var(--color-surface)", border: "1px solid var(--color-phase-yellow)44" }}
              >
                <h3 className="text-xs font-mono tracking-wider uppercase mb-3 flex items-center gap-1.5" style={{ color: "var(--color-phase-yellow)" }}>
                  <AlertTriangle className="w-3.5 h-3.5" />
                  Pendências Técnicas da Nuvemshop
                </h3>
                <div className="space-y-2">
                  {NUVEMSHOP_PENDENCIAS.map((p) => (
                    <div key={p.number} className="flex items-start gap-2 text-sm">
                      <span className="font-mono text-xs mt-0.5 shrink-0 text-muted-foreground">{String(p.number).padStart(2, "0")}</span>
                      <span className={`w-2 h-2 rounded-full mt-1.5 shrink-0 ${
                        p.status === "pendente" ? "bg-destructive" : p.status === "parcial" ? "bg-yellow-400" : "bg-green-400"
                      }`} />
                      <span className="text-foreground leading-relaxed">{p.text}</span>
                    </div>
                  ))}
                </div>
                <div className="flex items-center gap-4 mt-3 text-xs text-muted-foreground">
                  <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-destructive" /> Pendente</span>
                  <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-yellow-400" /> Parcial</span>
                  <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-green-400" /> Pronto</span>
                </div>
              </div>
            )}

            {/* Pontos Decisórios — show relevant ones per topic */}
            {PONTOS_DECISORIOS.filter(p => p.topicId === topic.id).length > 0 && (
              <div
                className="rounded-lg p-5 mb-5"
                style={{ backgroundColor: "var(--color-surface)", border: "1px solid var(--color-phase-red)44" }}
              >
                <h3 className="text-xs font-mono tracking-wider uppercase mb-3 flex items-center gap-1.5" style={{ color: "var(--color-phase-red)" }}>
                  <AlertTriangle className="w-3.5 h-3.5" />
                  Pontos Decisórios
                </h3>
                <div className="space-y-4">
                  {PONTOS_DECISORIOS.filter(p => p.topicId === topic.id).map((p, i) => (
                    <div key={i}>
                      <h4 className="text-sm font-semibold text-foreground mb-1">{p.title}</h4>
                      <p className="text-xs text-muted-foreground mb-2 leading-relaxed">{p.context}</p>
                      <div className="flex flex-wrap gap-2">
                        {p.options.map((opt, j) => (
                          <span key={j} className="text-xs px-2.5 py-1 rounded-md border border-border text-foreground">
                            Opção {j + 1}: {opt}
                          </span>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Important Dates — only for Datas Importantes do Ano (2b) */}
            {topic.id === "2b" && (
              <div
                className="rounded-lg p-5 mb-5 space-y-4"
                style={{ backgroundColor: "var(--color-surface)", border: "1px solid var(--color-gold)33" }}
              >
                <h3 className="text-xs font-mono tracking-wider uppercase mb-3 flex items-center gap-1.5" style={{ color: "var(--color-gold)" }}>
                  <Calendar className="w-3.5 h-3.5" />
                  Calendário Completo 2026
                </h3>
                {IMPORTANT_DATES.map((m) => (
                  <div key={m.month}>
                    <h4 className="text-xs font-mono font-semibold text-foreground mb-1.5 tracking-wide uppercase">{m.month}</h4>
                    <div className="space-y-1">
                      {m.dates.map((d, i) => (
                        <div key={i} className="flex items-start gap-2 py-1 px-2 rounded text-xs" style={{ backgroundColor: "var(--color-surface-elevated)" }}>
                          <span className="font-mono text-muted-foreground w-14 shrink-0 text-right">{d.date}</span>
                          <span className={`font-semibold shrink-0 ${
                            d.priority === "alta" ? "text-destructive" : d.priority === "media" ? "text-yellow-400" : "text-muted-foreground"
                          }`}>{d.name}</span>
                          <span className="text-muted-foreground"> — {d.note}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
                <div>
                  <h4 className="text-xs font-mono font-semibold text-foreground mb-1.5 tracking-wide uppercase">Datas Transversais</h4>
                  <div className="space-y-1">
                    {TRANSVERSAL_DATES.map((t, i) => (
                      <div key={i} className="flex items-start gap-2 py-1 px-2 rounded text-xs" style={{ backgroundColor: "var(--color-surface-elevated)" }}>
                        <span className="text-muted-foreground">{t}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* Decision box */}
            <div
              className="rounded-lg p-5 mb-5"
              style={{ backgroundColor: "var(--color-surface)", border: "1px solid var(--border)" }}
            >
              <h3 className="text-xs font-mono tracking-wider uppercase text-muted-foreground mb-3">
                Decisão a ser tomada
              </h3>
              <p className="text-sm text-foreground leading-relaxed">{topic.decision}</p>
            </div>

            {/* Dependencies */}
            {topic.dependencies.length > 0 && (
              <div
                className="rounded-lg p-4 mb-5"
                style={{ backgroundColor: "var(--color-surface)", border: "1px solid var(--border)" }}
              >
                <h3 className="text-xs font-mono tracking-wider uppercase text-muted-foreground mb-3 flex items-center gap-1.5">
                  <Link2 className="w-3 h-3" />
                  Dependências
                </h3>
                {topic.dependencies.map((dep, i) => (
                  <div key={i} className="flex items-start gap-2 text-sm">
                    <span className="font-mono text-xs px-1.5 py-0.5 rounded" style={{ backgroundColor: "var(--color-gold)", color: "var(--background)" }}>
                      {dep.targetId}
                    </span>
                    <div>
                      <span className="font-semibold text-foreground">{dep.label}</span>
                      <p className="text-muted-foreground text-xs mt-0.5">{dep.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* Register decision */}
            <div
              className="rounded-lg p-4 mb-4"
              style={{ backgroundColor: "var(--color-surface)", border: "1px solid var(--border)" }}
            >
              <h3 className="text-xs font-mono tracking-wider uppercase text-muted-foreground mb-3">
                Registrar Decisão
              </h3>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={decisionInput}
                  onChange={(e) => setDecisionInput(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && handleAddDecision()}
                  placeholder="Descreva a decisão tomada..."
                  className="flex-1 bg-background border border-border rounded-md px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-ring"
                />
                <Button
                  onClick={handleAddDecision}
                  size="sm"
                  disabled={!decisionInput.trim()}
                  style={{ backgroundColor: "var(--color-gold)", color: "var(--background)" }}
                >
                  <Plus className="w-4 h-4 mr-1" />
                  Registrar
                </Button>
              </div>
            </div>

            {/* Dependency Map */}
            <DependencyMap activeTopicId={topic.id} />

            {/* Park item */}
            {!showParkInput ? (
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowParkInput(true)}
                className="text-xs text-muted-foreground"
              >
                <ParkingCircle className="w-3.5 h-3.5 mr-1.5" />
                Estacionar este tópico
              </Button>
            ) : (
              <div
                className="rounded-lg p-4"
                style={{ backgroundColor: "var(--color-surface)", border: "1px solid var(--border)" }}
              >
                <h3 className="text-xs font-mono tracking-wider uppercase text-muted-foreground mb-3">
                  Estacionar Tópico
                </h3>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={parkReason}
                    onChange={(e) => setParkReason(e.target.value)}
                    onKeyDown={(e) => e.key === "Enter" && handlePark()}
                    placeholder="Motivo (opcional)..."
                    className="flex-1 bg-background border border-border rounded-md px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-ring"
                  />
                  <Button onClick={handlePark} size="sm" variant="secondary">
                    Estacionar
                  </Button>
                  <Button onClick={() => setShowParkInput(false)} size="sm" variant="ghost">
                    Cancelar
                  </Button>
                </div>
              </div>
            )}
          </motion.div>
        </AnimatePresence>
      </div>
    </main>
  );
}
