import { Pause, Play, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { formatTime } from "@/lib/utils-timer";
import { TOTAL_MEETING_MINUTES, allTopics } from "@/lib/meetingData";

interface MeetingHeaderProps {
  globalElapsed: number;
  globalProgress: number;
  isOvertime: boolean;
  meetingPaused: boolean;
  onTogglePause: () => void;
  activeTopicIndex: number;
  totalTopics: number;
}

export function MeetingHeader({
  globalElapsed,
  globalProgress,
  isOvertime,
  meetingPaused,
  onTogglePause,
  activeTopicIndex,
}: MeetingHeaderProps) {
  const remaining = Math.max(TOTAL_MEETING_MINUTES * 60 - globalElapsed, 0);

  return (
    <header className="shrink-0 border-b border-border">
      <div className="flex items-center justify-between px-5 py-3">
        {/* Left: Brand */}
        <div className="flex items-center gap-3">
          <h1 className="text-lg font-bold" style={{ color: "var(--color-gold)" }}>
            Mr. Lion
          </h1>
          <span className="text-xs font-mono text-muted-foreground tracking-wider uppercase">
            Reunião 13/02
          </span>
        </div>

        {/* Center: Global Timer */}
        <div className="flex items-center gap-4">
          <Button
            variant="ghost"
            size="sm"
            onClick={onTogglePause}
            className="h-8 w-8 p-0"
          >
            {meetingPaused ? (
              <Play className="w-4 h-4" style={{ color: "var(--color-gold)" }} />
            ) : (
              <Pause className="w-4 h-4 text-muted-foreground" />
            )}
          </Button>

          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4 text-muted-foreground" />
            <span
              className={`font-mono text-2xl font-bold tracking-tight ${
                isOvertime ? "timer-danger timer-shake" : ""
              }`}
              style={{ color: isOvertime ? undefined : "var(--color-gold)" }}
            >
              {formatTime(globalElapsed)}
            </span>
          </div>

          <div className="flex items-center gap-2 text-xs text-muted-foreground font-mono">
            <span>Restam</span>
            <span className={isOvertime ? "text-destructive font-semibold" : ""}>
              {isOvertime ? "OVERTIME" : formatTime(remaining)}
            </span>
          </div>
        </div>

        {/* Right: Topic counter */}
        <div className="flex items-center gap-3">
          <span className="text-xs font-mono text-muted-foreground">
            Tópico {activeTopicIndex + 1} de {allTopics.length}
          </span>
        </div>
      </div>

      {/* Progress bar */}
      <div className="h-1 w-full" style={{ backgroundColor: "var(--color-surface)" }}>
        <div
          className="h-full transition-all duration-1000 ease-linear"
          style={{
            width: `${globalProgress}%`,
            backgroundColor: isOvertime ? "var(--color-phase-red)" : "var(--color-gold)",
          }}
        />
      </div>
    </header>
  );
}
