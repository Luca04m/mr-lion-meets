import { useState } from "react";
import { ChevronDown, ChevronUp } from "lucide-react";
import { DEPENDENCY_CONNECTIONS } from "@/lib/meetingData";

interface DependencyMapProps {
  activeTopicId: string;
}

interface NodePosition {
  id: string;
  label: string;
  x: number;
  y: number;
}

export function DependencyMap({ activeTopicId }: DependencyMapProps) {
  const [isOpen, setIsOpen] = useState(false);

  // Layout: 2 rows of dependency pairs
  const nodes: NodePosition[] = [
    { id: "1a", label: "Nuvemshop", x: 100, y: 40 },
    { id: "3b", label: "Mr. Lion Nation", x: 420, y: 40 },
    { id: "5a", label: "Kit PDV", x: 100, y: 100 },
    { id: "4a", label: "Estr. Comercial", x: 420, y: 100 },
  ];

  const nodeWidth = 140;
  const nodeHeight = 30;

  const getStrokeDash = (type: string) => {
    switch (type) {
      case "destrava": return "none";
      case "apoia": return "3,3";
      default: return "none";
    }
  };

  return (
    <div
      className="rounded-lg mt-4 overflow-hidden"
      style={{ backgroundColor: "var(--color-surface)", border: "1px solid var(--border)" }}
    >
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-full flex items-center justify-between px-4 py-2.5 text-left hover:bg-accent/30 transition-colors"
      >
        <span className="text-xs font-mono tracking-wider uppercase text-muted-foreground font-semibold">
          Mapa de Dependências
        </span>
        {isOpen ? (
          <ChevronUp className="w-4 h-4 text-muted-foreground" />
        ) : (
          <ChevronDown className="w-4 h-4 text-muted-foreground" />
        )}
      </button>

      {isOpen && (
        <div className="px-4 pb-4">
          {/* Legend */}
          <div className="flex items-center gap-5 mb-3">
            <div className="flex items-center gap-1.5">
              <svg width="24" height="2"><line x1="0" y1="1" x2="24" y2="1" stroke="var(--color-gold)" strokeWidth="2" /></svg>
              <span className="text-[10px] text-muted-foreground">destrava</span>
            </div>
            <div className="flex items-center gap-1.5">
              <svg width="24" height="2"><line x1="0" y1="1" x2="24" y2="1" stroke="var(--color-gold)" strokeWidth="2" strokeDasharray="3,3" /></svg>
              <span className="text-[10px] text-muted-foreground">apoia</span>
            </div>
          </div>

          <svg width="100%" viewBox="0 0 560 150" className="max-w-full">
            <defs>
              <marker
                id="arrowhead"
                markerWidth="8"
                markerHeight="6"
                refX="8"
                refY="3"
                orient="auto"
              >
                <polygon points="0 0, 8 3, 0 6" fill="var(--color-gold-dim)" />
              </marker>
            </defs>

            {/* Connection lines */}
            {DEPENDENCY_CONNECTIONS.map((conn, i) => {
              const fromNode = nodes.find((n) => n.id === conn.from);
              const toNode = nodes.find((n) => n.id === conn.to);
              if (!fromNode || !toNode) return null;

              const x1 = fromNode.x + nodeWidth;
              const y1 = fromNode.y + nodeHeight / 2;
              const x2 = toNode.x;
              const y2 = toNode.y + nodeHeight / 2;

              const isActive = activeTopicId === conn.from || activeTopicId === conn.to;

              return (
                <g key={i}>
                  <line
                    x1={x1}
                    y1={y1}
                    x2={x2 - 4}
                    y2={y2}
                    stroke={isActive ? "var(--color-gold)" : "var(--color-gold-dim)"}
                    strokeWidth={isActive ? 2 : 1.5}
                    strokeDasharray={getStrokeDash(conn.type)}
                    markerEnd="url(#arrowhead)"
                    opacity={isActive ? 1 : 0.5}
                  />
                  {/* Label on line */}
                  <text
                    x={(x1 + x2) / 2}
                    y={y1 - 6}
                    textAnchor="middle"
                    fill="var(--color-muted-foreground)"
                    fontSize="9"
                    fontFamily="'JetBrains Mono', monospace"
                    opacity={isActive ? 1 : 0.5}
                  >
                    {conn.label}
                  </text>
                </g>
              );
            })}

            {/* Nodes */}
            {nodes.map((node) => {
              const isActive = activeTopicId === node.id;
              return (
                <g key={node.id}>
                  <rect
                    x={node.x}
                    y={node.y}
                    width={nodeWidth}
                    height={nodeHeight}
                    rx={4}
                    fill={isActive ? "var(--color-surface-elevated)" : "var(--background)"}
                    stroke={isActive ? "var(--color-gold)" : "var(--border)"}
                    strokeWidth={isActive ? 2 : 1}
                  />
                  {isActive && (
                    <rect
                      x={node.x}
                      y={node.y}
                      width={nodeWidth}
                      height={nodeHeight}
                      rx={4}
                      fill="none"
                      stroke="var(--color-gold)"
                      strokeWidth={2}
                      opacity={0.3}
                    >
                      <animate
                        attributeName="opacity"
                        values="0.3;0.8;0.3"
                        dur="2s"
                        repeatCount="indefinite"
                      />
                    </rect>
                  )}
                  <text
                    x={node.x + nodeWidth / 2}
                    y={node.y + nodeHeight / 2 + 1}
                    textAnchor="middle"
                    dominantBaseline="middle"
                    fill={isActive ? "var(--color-gold)" : "var(--foreground)"}
                    fontSize="11"
                    fontFamily="'Space Grotesk', sans-serif"
                    fontWeight={isActive ? 600 : 400}
                  >
                    {node.label}
                  </text>
                </g>
              );
            })}
          </svg>
        </div>
      )}
    </div>
  );
}
