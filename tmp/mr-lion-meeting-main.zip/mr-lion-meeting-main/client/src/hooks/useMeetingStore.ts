import { useState, useCallback, useRef, useEffect } from "react";
import { allTopics, TOTAL_MEETING_MINUTES, type TopicStatus } from "@/lib/meetingData";

export interface DecisionRecord {
  topicId: string;
  topicTitle: string;
  text: string;
  timestamp: number;
}

export interface ParkedItem {
  topicId: string;
  topicTitle: string;
  reason: string;
  timestamp: number;
}

export function useMeetingStore() {
  const [meetingStarted, setMeetingStarted] = useState(false);
  const [meetingPaused, setMeetingPaused] = useState(false);
  const [globalElapsed, setGlobalElapsed] = useState(0);
  const [activeTopicIndex, setActiveTopicIndex] = useState(0);
  const [topicElapsed, setTopicElapsed] = useState<Record<string, number>>({});
  const [topicStatuses, setTopicStatuses] = useState<Record<string, TopicStatus>>({});
  const [decisions, setDecisions] = useState<DecisionRecord[]>([]);
  const [parkedItems, setParkedItems] = useState<ParkedItem[]>([]);

  const globalIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const topicIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // Fix stale closure: keep activeTopicIndex in a ref
  const activeTopicIndexRef = useRef(activeTopicIndex);
  activeTopicIndexRef.current = activeTopicIndex;

  const activeTopic = allTopics[activeTopicIndex];

  // Initialize topic statuses
  useEffect(() => {
    const initial: Record<string, TopicStatus> = {};
    allTopics.forEach(() => {
      // all start as waiting
    });
    allTopics.forEach((t) => {
      initial[t.id] = "waiting";
    });
    setTopicStatuses(initial);
  }, []);

  const startTimers = useCallback(() => {
    if (globalIntervalRef.current) clearInterval(globalIntervalRef.current);
    if (topicIntervalRef.current) clearInterval(topicIntervalRef.current);

    globalIntervalRef.current = setInterval(() => {
      setGlobalElapsed((prev) => prev + 1);
    }, 1000);

    topicIntervalRef.current = setInterval(() => {
      const topic = allTopics[activeTopicIndexRef.current];
      if (topic) {
        setTopicElapsed((prev) => ({
          ...prev,
          [topic.id]: (prev[topic.id] || 0) + 1,
        }));
      }
    }, 1000);
  }, []);

  const pauseTimers = useCallback(() => {
    if (globalIntervalRef.current) {
      clearInterval(globalIntervalRef.current);
      globalIntervalRef.current = null;
    }
    if (topicIntervalRef.current) {
      clearInterval(topicIntervalRef.current);
      topicIntervalRef.current = null;
    }
  }, []);

  const startMeeting = useCallback(() => {
    setMeetingStarted(true);
    setMeetingPaused(false);
    setTopicStatuses((prev) => ({ ...prev, [allTopics[0].id]: "active" }));
    setActiveTopicIndex(0);
  }, []);

  // Manage timers based on meeting state
  useEffect(() => {
    if (meetingStarted && !meetingPaused) {
      startTimers();
    } else {
      pauseTimers();
    }
    return () => pauseTimers();
  }, [meetingStarted, meetingPaused, startTimers, pauseTimers]);

  const togglePause = useCallback(() => {
    setMeetingPaused((prev) => !prev);
  }, []);

  const goToTopic = useCallback((index: number) => {
    if (index < 0 || index >= allTopics.length) return;

    setActiveTopicIndex((prevIndex) => {
      setTopicStatuses((prev) => {
        const next = { ...prev };
        const currentTopic = allTopics[prevIndex];
        if (currentTopic && next[currentTopic.id] === "active") {
          next[currentTopic.id] = "completed";
        }
        next[allTopics[index].id] = "active";
        return next;
      });
      return index;
    });
  }, []);

  const nextTopic = useCallback(() => {
    setActiveTopicIndex((prev) => {
      const next = prev + 1;
      if (next < allTopics.length) {
        goToTopic(next);
      }
      return prev;
    });
  }, [goToTopic]);

  const prevTopic = useCallback(() => {
    setActiveTopicIndex((prev) => {
      const next = prev - 1;
      if (next >= 0) {
        goToTopic(next);
      }
      return prev;
    });
  }, [goToTopic]);

  const addDecision = useCallback((topicId: string, topicTitle: string, text: string) => {
    setDecisions((prev) => [
      ...prev,
      { topicId, topicTitle, text, timestamp: Date.now() },
    ]);
  }, []);

  const removeDecision = useCallback((index: number) => {
    setDecisions((prev) => prev.filter((_, i) => i !== index));
  }, []);

  const parkItem = useCallback((topicId: string, topicTitle: string, reason: string) => {
    setParkedItems((prev) => [
      ...prev,
      { topicId, topicTitle, reason, timestamp: Date.now() },
    ]);
    setTopicStatuses((prev) => ({ ...prev, [topicId]: "parked" }));
    // Auto-advance if parking the active topic
    const currentIdx = activeTopicIndexRef.current;
    if (allTopics[currentIdx]?.id === topicId) {
      const nextIdx = currentIdx + 1;
      if (nextIdx < allTopics.length) {
        goToTopic(nextIdx);
      }
    }
  }, [goToTopic]);

  const removeParkedItem = useCallback((index: number) => {
    setParkedItems((prev) => prev.filter((_, i) => i !== index));
  }, []);

  const globalProgress = Math.min((globalElapsed / (TOTAL_MEETING_MINUTES * 60)) * 100, 100);
  const isOvertime = globalElapsed > TOTAL_MEETING_MINUTES * 60;

  return {
    meetingStarted,
    meetingPaused,
    globalElapsed,
    globalProgress,
    isOvertime,
    activeTopicIndex,
    activeTopic,
    topicElapsed,
    topicStatuses,
    decisions,
    parkedItems,
    startMeeting,
    togglePause,
    goToTopic,
    nextTopic,
    prevTopic,
    addDecision,
    removeDecision,
    parkItem,
    removeParkedItem,
  };
}
