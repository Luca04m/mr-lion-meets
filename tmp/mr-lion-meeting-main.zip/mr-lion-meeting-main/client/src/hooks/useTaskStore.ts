import { useCallback, useEffect, useMemo, useState } from "react";
import { trpc } from "@/lib/trpc";
import { io, Socket } from "socket.io-client";
import type { Task, Status } from "@/lib/taskData";
import { toast } from "sonner";

const USERNAME_KEY = "mrlion-username";

// Singleton socket
let socket: Socket | null = null;
function getSocket(): Socket {
  if (!socket) {
    socket = io({
      path: "/api/socket",
      transports: ["websocket", "polling"],
    });
  }
  return socket;
}

export function useUserName() {
  const [userName, setUserNameState] = useState<string>(() => {
    try {
      return localStorage.getItem(USERNAME_KEY) || "";
    } catch {
      return "";
    }
  });

  const setUserName = useCallback((name: string) => {
    setUserNameState(name);
    try {
      localStorage.setItem(USERNAME_KEY, name);
    } catch {
      // ignore
    }
    // Notify socket
    const s = getSocket();
    s.emit("user:join", { name });
  }, []);

  return { userName, setUserName, hasName: userName.length > 0 };
}

export function usePresence(userName: string) {
  const [onlineUsers, setOnlineUsers] = useState<string[]>([]);

  useEffect(() => {
    if (!userName) return;
    const s = getSocket();
    s.emit("user:join", { name: userName });

    const handler = (data: { users: string[]; count: number }) => {
      setOnlineUsers(data.users);
    };
    s.on("presence:update", handler);
    return () => {
      s.off("presence:update", handler);
    };
  }, [userName]);

  return onlineUsers;
}

export function useTaskStore(userName: string) {
  const utils = trpc.useUtils();

  // Fetch tasks from DB
  const { data: dbTasks, isLoading } = trpc.tasks.list.useQuery(undefined, {
    refetchOnWindowFocus: true,
    staleTime: 5000,
  });

  // Mutations
  const updateStatusMut = trpc.tasks.updateStatus.useMutation({
    onSuccess: () => utils.tasks.list.invalidate(),
  });
  const updateNotesMut = trpc.tasks.updateNotes.useMutation({
    onSuccess: () => utils.tasks.list.invalidate(),
  });
  const createTaskMut = trpc.tasks.create.useMutation({
    onSuccess: () => utils.tasks.list.invalidate(),
  });
  const updateTaskMut = trpc.tasks.update.useMutation({
    onSuccess: () => utils.tasks.list.invalidate(),
  });
  const deleteTaskMut = trpc.tasks.delete.useMutation({
    onSuccess: () => utils.tasks.list.invalidate(),
  });

  // Listen for real-time updates via Socket.io
  useEffect(() => {
    const s = getSocket();

    const onTaskUpdated = () => {
      utils.tasks.list.invalidate();
    };
    const onTaskCreated = (data: { id: number; userName: string }) => {
      utils.tasks.list.invalidate();
      if (data.userName !== userName) {
        toast.info(`${data.userName} criou uma nova tarefa`);
      }
    };
    const onTaskDeleted = (data: { id: number; userName: string }) => {
      utils.tasks.list.invalidate();
      if (data.userName !== userName) {
        toast.info(`${data.userName} removeu uma tarefa`);
      }
    };

    s.on("task:updated", onTaskUpdated);
    s.on("task:created", onTaskCreated);
    s.on("task:deleted", onTaskDeleted);

    return () => {
      s.off("task:updated", onTaskUpdated);
      s.off("task:created", onTaskCreated);
      s.off("task:deleted", onTaskDeleted);
    };
  }, [userName, utils]);

  // Map DB rows to frontend Task type
  const tasks: Task[] = useMemo(() => {
    if (!dbTasks) return [];
    return dbTasks.map((row) => ({
      id: row.id,
      title: row.title,
      detail: row.detail || "",
      responsible: (row.responsible as string[]) || [],

      priority: row.priority as Task["priority"],
      area: row.area as Task["area"],
      status: row.status as Task["status"],
      dependencies: (row.dependencies as number[]) || [],
      notes: row.notes || "",
      decision: row.decision || null,
    }));
  }, [dbTasks]);

  const updateTaskStatus = useCallback(
    (id: number, status: Status) => {
      if (!userName) return;
      updateStatusMut.mutate({ id, status, userName });
    },
    [userName, updateStatusMut]
  );

  const updateTaskNotes = useCallback(
    (id: number, notes: string) => {
      if (!userName) return;
      updateNotesMut.mutate({ id, notes, userName });
    },
    [userName, updateNotesMut]
  );

  const createTask = useCallback(
    (data: {
      title: string;
      detail?: string;
      responsible: string[];
      priority?: Task["priority"];
      area: string;
    }) => {
      if (!userName) return;
      createTaskMut.mutate({
        title: data.title,
        detail: data.detail || "",
        responsible: data.responsible,
        priority: data.priority || "media",
        area: data.area,
        userName,
      });
    },
    [userName, createTaskMut]
  );

  const editTask = useCallback(
    (id: number, data: Partial<Task>) => {
      if (!userName) return;
      const { notes, ...rest } = data;
      updateTaskMut.mutate({
        id,
        ...rest,
        userName,
      });
    },
    [userName, updateTaskMut]
  );

  const removeTask = useCallback(
    (id: number) => {
      if (!userName) return;
      deleteTaskMut.mutate({ id, userName });
    },
    [userName, deleteTaskMut]
  );

  const stats = useMemo(() => ({
    total: tasks.length,
    pendente: tasks.filter((t) => t.status === "pendente").length,
    emAndamento: tasks.filter((t) => t.status === "em-andamento").length,
    concluida: tasks.filter((t) => t.status === "concluida").length,
    atrasada: tasks.filter((t) => t.status === "atrasada").length,
    alta: tasks.filter((t) => t.priority === "alta").length,
    media: tasks.filter((t) => t.priority === "media").length,
    baixa: tasks.filter((t) => t.priority === "baixa").length,
  }), [tasks]);

  return {
    tasks,
    isLoading,
    updateTaskStatus,
    updateTaskNotes,
    createTask,
    editTask,
    removeTask,
    stats,
  };
}

export function useActivityFeed() {
  const { data, isLoading } = trpc.activity.recent.useQuery(
    { limit: 50 },
    { refetchInterval: 10000 }
  );

  return {
    activities: data || [],
    isLoading,
  };
}
