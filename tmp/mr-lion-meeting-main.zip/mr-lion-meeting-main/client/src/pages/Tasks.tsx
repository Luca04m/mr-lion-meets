/*
 * Tasks Page — Mr. Lion Collaborative Task Management
 * Features: Overview, By Person, By Area, Activity, Meetings (PDF upload)
 * Edit dialog, completion celebration, completion filter
 */
import { useState, useMemo, useCallback, useRef } from "react";
import { useTaskStore, useUserName, usePresence, useActivityFeed } from "@/hooks/useTaskStore";
import { trpc } from "@/lib/trpc";
import {
  Task,
  Status,
  Priority,
  Area,
  TEAM_MEMBERS,
  AREA_LABELS,
  AREA_COLORS,
  PRIORITY_COLORS,
  STATUS_COLORS,
  STATUS_LABELS,
  getTasksForMember,
  getTasksForArea,
} from "@/lib/taskData";
import {
  LayoutDashboard,
  Users,
  FolderKanban,
  ChevronDown,
  ChevronRight,
  ArrowUpDown,
  Search,
  Download,
  Plus,
  Trash2,
  Edit3,
  CheckCircle2,
  Clock,
  AlertTriangle,
  Circle,
  Link2,
  StickyNote,
  X,
  Activity,
  Wifi,
  User,
  FileText,
  Upload,
  Calendar,
  Eye,
  PartyPopper,
  Filter,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import confetti from "canvas-confetti";

type ViewTab = "overview" | "person" | "area" | "activity" | "meetings";

const TABS: { id: ViewTab; label: string; icon: React.ReactNode }[] = [
  { id: "overview", label: "Visão Geral", icon: <LayoutDashboard size={16} /> },
  { id: "person", label: "Por Pessoa", icon: <Users size={16} /> },
  { id: "area", label: "Por Área", icon: <FolderKanban size={16} /> },
  { id: "activity", label: "Atividade", icon: <Activity size={16} /> },
  { id: "meetings", label: "Reuniões", icon: <FileText size={16} /> },
];

// ─── Celebration helper ──────────────────────────────────────────

function fireCelebration() {
  const defaults = {
    spread: 60,
    ticks: 50,
    gravity: 1.2,
    decay: 0.94,
    startVelocity: 20,
    colors: ["#d4a843", "#f5d77a", "#10b981", "#6366f1", "#f59e0b"],
  };

  confetti({
    ...defaults,
    particleCount: 30,
    scalar: 0.8,
    shapes: ["star"],
    origin: { x: 0.5, y: 0.6 },
  });

  setTimeout(() => {
    confetti({
      ...defaults,
      particleCount: 20,
      scalar: 0.6,
      shapes: ["circle"],
      origin: { x: 0.4, y: 0.65 },
    });
  }, 150);
}

// ─── User Name Prompt ────────────────────────────────────────────

function UserNamePrompt({ onSubmit }: { onSubmit: (name: string) => void }) {
  const [name, setName] = useState("");
  return (
    <div className="min-h-screen bg-background flex items-center justify-center">
      <div className="max-w-md w-full mx-4">
        <div className="border border-gold/30 rounded-2xl p-8 bg-surface/50 backdrop-blur-sm text-center space-y-6">
          <div>
            <h1 className="text-2xl font-bold text-foreground tracking-tight">
              <span className="text-gold">MR. LION</span> — Tarefas
            </h1>
            <p className="text-sm text-muted-foreground mt-2">
              Identifique-se para acompanhar e gerenciar as tarefas da equipe em tempo real.
            </p>
          </div>
          <div className="space-y-3">
            <div className="grid grid-cols-2 gap-2">
              {TEAM_MEMBERS.map((member) => (
                <button
                  key={member}
                  onClick={() => onSubmit(member)}
                  className={`px-4 py-3 rounded-lg border text-sm font-medium transition-all ${
                    name === member
                      ? "border-gold bg-gold/10 text-gold"
                      : "border-border/50 bg-surface hover:border-gold/50 text-foreground"
                  }`}
                >
                  {member}
                </button>
              ))}
            </div>
            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <span className="w-full border-t border-border/50" />
              </div>
              <div className="relative flex justify-center text-xs uppercase">
                <span className="bg-surface/50 px-2 text-muted-foreground">ou</span>
              </div>
            </div>
            <div className="flex gap-2">
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Outro nome..."
                className="flex-1 px-4 py-2.5 rounded-lg border border-border/50 bg-background text-foreground text-sm placeholder:text-muted-foreground focus:ring-1 focus:ring-gold focus:border-gold outline-none"
                onKeyDown={(e) => {
                  if (e.key === "Enter" && name.trim()) onSubmit(name.trim());
                }}
              />
              <Button
                onClick={() => name.trim() && onSubmit(name.trim())}
                disabled={!name.trim()}
                className="bg-gold text-background hover:bg-gold/90"
              >
                Entrar
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── Presence Bar ────────────────────────────────────────────────

function PresenceBar({ users }: { users: string[] }) {
  if (users.length === 0) return null;
  return (
    <div className="flex items-center gap-2">
      <Wifi size={12} className="text-green-400" />
      <div className="flex gap-1">
        {users.map((u) => (
          <span
            key={u}
            className="text-[10px] px-2 py-0.5 rounded-full bg-green-500/10 text-green-400 border border-green-500/20"
          >
            {u}
          </span>
        ))}
      </div>
    </div>
  );
}

// ─── Status helpers ──────────────────────────────────────────────

function StatusIcon({ status }: { status: Status }) {
  switch (status) {
    case "concluida":
      return <CheckCircle2 size={14} style={{ color: STATUS_COLORS.concluida }} />;
    case "em-andamento":
      return <Clock size={14} style={{ color: STATUS_COLORS["em-andamento"] }} />;
    case "atrasada":
      return <AlertTriangle size={14} style={{ color: STATUS_COLORS.atrasada }} />;
    default:
      return <Circle size={14} style={{ color: STATUS_COLORS.pendente }} />;
  }
}

function PriorityBadge({ priority }: { priority: Priority }) {
  const labels: Record<Priority, string> = { alta: "Alta", media: "Média", baixa: "Baixa" };
  return (
    <span
      className="text-[10px] font-bold uppercase tracking-wider px-1.5 py-0.5 rounded"
      style={{
        color: PRIORITY_COLORS[priority],
        backgroundColor: `${PRIORITY_COLORS[priority]}18`,
        border: `1px solid ${PRIORITY_COLORS[priority]}30`,
      }}
    >
      {labels[priority]}
    </span>
  );
}

function StatusSelect({
  status,
  onChange,
}: {
  status: Status;
  onChange: (s: Status) => void;
}) {
  return (
    <select
      value={status}
      onChange={(e) => onChange(e.target.value as Status)}
      className="text-xs bg-surface border border-border rounded px-2 py-1 text-foreground focus:ring-1 focus:ring-gold"
      style={{ backgroundColor: "var(--color-surface)" }}
    >
      {(Object.keys(STATUS_LABELS) as Status[]).map((s) => (
        <option key={s} value={s}>
          {STATUS_LABELS[s]}
        </option>
      ))}
    </select>
  );
}

// ─── Completion Toggle ──────────────────────────────────────────

function CompletionToggle({
  status,
  onToggle,
}: {
  status: Status;
  onToggle: () => void;
}) {
  const isComplete = status === "concluida";
  return (
    <button
      onClick={(e) => {
        e.stopPropagation();
        onToggle();
      }}
      className={`w-5 h-5 rounded-full border-2 flex items-center justify-center transition-all shrink-0 ${
        isComplete
          ? "border-green-500 bg-green-500/20"
          : "border-muted-foreground/40 hover:border-gold"
      }`}
      title={isComplete ? "Marcar como pendente" : "Marcar como concluída"}
    >
      {isComplete && <CheckCircle2 size={12} className="text-green-500" />}
    </button>
  );
}

// ─── Edit Task Dialog ───────────────────────────────────────────

function EditTaskDialog({
  task,
  onClose,
  onSave,
}: {
  task: Task;
  onClose: () => void;
  onSave: (id: number, data: Partial<Task>) => void;
}) {
  const [title, setTitle] = useState(task.title);
  const [detail, setDetail] = useState(task.detail);
  const [responsible, setResponsible] = useState<string[]>([...task.responsible]);
  const [priority, setPriority] = useState<Priority>(task.priority);
  const [area, setArea] = useState(task.area);
  const [status, setStatus] = useState<Status>(task.status);

  const areas = Object.keys(AREA_LABELS) as Area[];

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-surface border border-border rounded-2xl max-w-lg w-full p-6 space-y-4 max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-bold text-foreground flex items-center gap-2">
            <Edit3 size={18} className="text-gold" />
            Editar Tarefa #{String(task.id).padStart(2, "0")}
          </h2>
          <button onClick={onClose} className="text-muted-foreground hover:text-foreground">
            <X size={18} />
          </button>
        </div>

        <div className="space-y-3">
          <div>
            <label className="text-xs text-muted-foreground block mb-1">Título *</label>
            <input
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full px-3 py-2 rounded-lg border border-border bg-background text-foreground text-sm focus:ring-1 focus:ring-gold outline-none"
            />
          </div>

          <div>
            <label className="text-xs text-muted-foreground block mb-1">Detalhes</label>
            <textarea
              value={detail}
              onChange={(e) => setDetail(e.target.value)}
              className="w-full px-3 py-2 rounded-lg border border-border bg-background text-foreground text-sm resize-none focus:ring-1 focus:ring-gold outline-none"
              rows={3}
            />
          </div>

          <div>
            <label className="text-xs text-muted-foreground block mb-1">Responsáveis *</label>
            <div className="flex flex-wrap gap-2">
              {TEAM_MEMBERS.map((m) => (
                <button
                  key={m}
                  onClick={() =>
                    setResponsible((prev) =>
                      prev.includes(m) ? prev.filter((p) => p !== m) : [...prev, m]
                    )
                  }
                  className={`text-xs px-3 py-1.5 rounded-lg border transition-all ${
                    responsible.includes(m)
                      ? "border-gold bg-gold/10 text-gold"
                      : "border-border bg-background text-muted-foreground hover:border-gold/50"
                  }`}
                >
                  {m}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs text-muted-foreground block mb-1">Prioridade</label>
              <select
                value={priority}
                onChange={(e) => setPriority(e.target.value as Priority)}
                className="w-full px-3 py-2 rounded-lg border border-border bg-background text-foreground text-sm focus:ring-1 focus:ring-gold outline-none"
              >
                <option value="alta">Alta</option>
                <option value="media">Média</option>
                <option value="baixa">Baixa</option>
              </select>
            </div>

            <div>
              <label className="text-xs text-muted-foreground block mb-1">Status</label>
              <select
                value={status}
                onChange={(e) => setStatus(e.target.value as Status)}
                className="w-full px-3 py-2 rounded-lg border border-border bg-background text-foreground text-sm focus:ring-1 focus:ring-gold outline-none"
              >
                {(Object.keys(STATUS_LABELS) as Status[]).map((s) => (
                  <option key={s} value={s}>
                    {STATUS_LABELS[s]}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label className="text-xs text-muted-foreground block mb-1">Área</label>
            <select
              value={area}
              onChange={(e) => setArea(e.target.value as Area)}
              className="w-full px-3 py-2 rounded-lg border border-border bg-background text-foreground text-sm focus:ring-1 focus:ring-gold outline-none"
            >
              {areas.map((a) => (
                <option key={a} value={a}>
                  {AREA_LABELS[a]}
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="flex gap-2 pt-2">
          <Button variant="outline" onClick={onClose} className="flex-1">
            Cancelar
          </Button>
          <Button
            onClick={() => {
              if (!title.trim() || responsible.length === 0) {
                toast.error("Preencha título e responsáveis");
                return;
              }
              onSave(task.id, { title, detail, responsible, priority, area, status });
              toast.success("Tarefa atualizada!");
              onClose();
            }}
            className="flex-1 bg-gold text-background hover:bg-gold/90"
          >
            Salvar Alterações
          </Button>
        </div>
      </div>
    </div>
  );
}

// ─── Task Row Component ──────────────────────────────────────────

function TaskRow({
  task,
  onStatusChange,
  onNotesChange,
  onDelete,
  onEdit,
  onToggleComplete,
  expanded,
  onToggle,
}: {
  task: Task;
  onStatusChange: (id: number, s: Status) => void;
  onNotesChange: (id: number, notes: string) => void;
  onDelete?: (id: number) => void;
  onEdit: (task: Task) => void;
  onToggleComplete: (id: number, currentStatus: Status) => void;
  expanded: boolean;
  onToggle: () => void;
}) {
  const [editingNotes, setEditingNotes] = useState(false);
  const [notesValue, setNotesValue] = useState(task.notes);
  const isComplete = task.status === "concluida";

  return (
    <div
      className={`border border-border/50 rounded-lg overflow-hidden mb-2 transition-all ${
        isComplete ? "opacity-50" : ""
      }`}
    >
      <div
        className="flex items-center gap-3 px-4 py-3 hover:bg-surface-elevated/50 transition-colors cursor-pointer"
        onClick={onToggle}
      >
        <CompletionToggle
          status={task.status}
          onToggle={() => onToggleComplete(task.id, task.status)}
        />
        <span className="text-gold font-mono text-xs w-8 shrink-0">
          #{String(task.id).padStart(2, "0")}
        </span>
        <StatusIcon status={task.status} />
        <span
          className={`flex-1 text-sm truncate ${
            isComplete ? "line-through text-muted-foreground" : "text-foreground"
          }`}
        >
          {task.title}
        </span>
        <div className="flex items-center gap-2 shrink-0">
          <PriorityBadge priority={task.priority} />
          <div className="flex gap-1">
            {task.responsible.map((r) => (
              <span
                key={r}
                className="text-[10px] px-1.5 py-0.5 rounded bg-muted text-muted-foreground"
              >
                {r}
              </span>
            ))}
          </div>
          <button
            className="text-muted-foreground hover:text-gold transition-colors"
            onClick={(e) => {
              e.stopPropagation();
              onEdit(task);
            }}
            title="Editar tarefa"
          >
            <Edit3 size={14} />
          </button>
          {expanded ? (
            <ChevronDown size={14} className="text-muted-foreground" />
          ) : (
            <ChevronRight size={14} className="text-muted-foreground" />
          )}
        </div>
      </div>

      {expanded && (
        <div className="px-4 pb-4 pt-1 border-t border-border/30 bg-surface/50 space-y-3">
          <p className="text-sm text-muted-foreground leading-relaxed">{task.detail}</p>

          <div className="flex flex-wrap gap-4 items-center">
            <div className="flex items-center gap-2">
              <span className="text-xs text-muted-foreground">Status:</span>
              <StatusSelect
                status={task.status}
                onChange={(s) => onStatusChange(task.id, s)}
              />
            </div>

            <div className="flex items-center gap-2">
              <span className="text-xs text-muted-foreground">Área:</span>
              <span
                className="text-xs px-1.5 py-0.5 rounded"
                style={{
                  color: AREA_COLORS[task.area],
                  backgroundColor: `${AREA_COLORS[task.area]}18`,
                }}
              >
                {AREA_LABELS[task.area]}
              </span>
            </div>
            {onDelete && (
              <button
                className="text-xs text-destructive hover:text-destructive/80 flex items-center gap-1 ml-auto"
                onClick={(e) => {
                  e.stopPropagation();
                  if (confirm("Remover esta tarefa?")) onDelete(task.id);
                }}
              >
                <Trash2 size={12} />
                Remover
              </button>
            )}
          </div>

          {task.dependencies.length > 0 && (
            <div className="flex items-center gap-2 text-xs">
              <Link2 size={12} className="text-muted-foreground" />
              <span className="text-muted-foreground">Depende de:</span>
              {task.dependencies.map((dep) => (
                <span key={dep} className="text-gold">
                  #{String(dep).padStart(2, "0")}
                </span>
              ))}
            </div>
          )}

          {task.decision && (
            <div className="flex items-center gap-2 text-xs">
              <CheckCircle2 size={12} className="text-green-400" />
              <span className="text-muted-foreground">Decisão:</span>
              <span className="text-green-400">{task.decision}</span>
            </div>
          )}

          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <StickyNote size={12} className="text-muted-foreground" />
              <span className="text-xs text-muted-foreground">Notas:</span>
              {!editingNotes && (
                <button
                  className="text-xs text-gold hover:underline"
                  onClick={(e) => {
                    e.stopPropagation();
                    setEditingNotes(true);
                    setNotesValue(task.notes);
                  }}
                >
                  {task.notes ? "Editar" : "Adicionar"}
                </button>
              )}
            </div>
            {editingNotes ? (
              <div className="flex gap-2">
                <textarea
                  value={notesValue}
                  onChange={(e) => setNotesValue(e.target.value)}
                  className="flex-1 text-sm bg-background border border-border rounded px-3 py-2 text-foreground resize-none"
                  rows={2}
                  autoFocus
                  onClick={(e) => e.stopPropagation()}
                />
                <div className="flex flex-col gap-1">
                  <Button
                    size="sm"
                    variant="default"
                    className="text-xs h-7"
                    onClick={(e) => {
                      e.stopPropagation();
                      onNotesChange(task.id, notesValue);
                      setEditingNotes(false);
                      toast.success("Nota salva");
                    }}
                  >
                    Salvar
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    className="text-xs h-7"
                    onClick={(e) => {
                      e.stopPropagation();
                      setEditingNotes(false);
                    }}
                  >
                    <X size={12} />
                  </Button>
                </div>
              </div>
            ) : task.notes ? (
              <p className="text-xs text-foreground/70 italic pl-5">{task.notes}</p>
            ) : null}
          </div>
        </div>
      )}
    </div>
  );
}

// ─── Create Task Dialog ──────────────────────────────────────────

function CreateTaskDialog({
  onClose,
  onCreate,
}: {
  onClose: () => void;
  onCreate: (data: {
    title: string;
    detail?: string;
    responsible: string[];
    priority?: Priority;
    area: string;
  }) => void;
}) {
  const [title, setTitle] = useState("");
  const [detail, setDetail] = useState("");
  const [responsible, setResponsible] = useState<string[]>([]);
  const [priority, setPriority] = useState<Priority>("media");
  const [area, setArea] = useState("comercial");

  const areas = Object.keys(AREA_LABELS) as Area[];

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-surface border border-border rounded-2xl max-w-lg w-full p-6 space-y-4 max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-bold text-foreground">Nova Tarefa</h2>
          <button onClick={onClose} className="text-muted-foreground hover:text-foreground">
            <X size={18} />
          </button>
        </div>

        <div className="space-y-3">
          <div>
            <label className="text-xs text-muted-foreground block mb-1">Título *</label>
            <input
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full px-3 py-2 rounded-lg border border-border bg-background text-foreground text-sm focus:ring-1 focus:ring-gold outline-none"
              placeholder="Título da tarefa"
            />
          </div>

          <div>
            <label className="text-xs text-muted-foreground block mb-1">Detalhes</label>
            <textarea
              value={detail}
              onChange={(e) => setDetail(e.target.value)}
              className="w-full px-3 py-2 rounded-lg border border-border bg-background text-foreground text-sm resize-none focus:ring-1 focus:ring-gold outline-none"
              rows={3}
              placeholder="Descrição detalhada"
            />
          </div>

          <div>
            <label className="text-xs text-muted-foreground block mb-1">Responsáveis *</label>
            <div className="flex flex-wrap gap-2">
              {TEAM_MEMBERS.map((m) => (
                <button
                  key={m}
                  onClick={() =>
                    setResponsible((prev) =>
                      prev.includes(m) ? prev.filter((p) => p !== m) : [...prev, m]
                    )
                  }
                  className={`text-xs px-3 py-1.5 rounded-lg border transition-all ${
                    responsible.includes(m)
                      ? "border-gold bg-gold/10 text-gold"
                      : "border-border bg-background text-muted-foreground hover:border-gold/50"
                  }`}
                >
                  {m}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="text-xs text-muted-foreground block mb-1">Prioridade</label>
            <select
              value={priority}
              onChange={(e) => setPriority(e.target.value as Priority)}
              className="w-full px-3 py-2 rounded-lg border border-border bg-background text-foreground text-sm focus:ring-1 focus:ring-gold outline-none"
            >
              <option value="alta">Alta</option>
              <option value="media">Média</option>
              <option value="baixa">Baixa</option>
            </select>
          </div>

          <div>
            <label className="text-xs text-muted-foreground block mb-1">Área</label>
            <select
              value={area}
              onChange={(e) => setArea(e.target.value as Area)}
              className="w-full px-3 py-2 rounded-lg border border-border bg-background text-foreground text-sm focus:ring-1 focus:ring-gold outline-none"
            >
              {areas.map((a) => (
                <option key={a} value={a}>
                  {AREA_LABELS[a]}
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="flex gap-2 pt-2">
          <Button variant="outline" onClick={onClose} className="flex-1">
            Cancelar
          </Button>
          <Button
            onClick={() => {
              if (!title.trim() || responsible.length === 0) {
                toast.error("Preencha título e responsáveis");
                return;
              }
              onCreate({ title, detail, responsible, priority, area });
              toast.success("Tarefa criada!");
              onClose();
            }}
            className="flex-1 bg-gold text-background hover:bg-gold/90"
          >
            Criar Tarefa
          </Button>
        </div>
      </div>
    </div>
  );
}

// ─── Stats Bar ───────────────────────────────────────────────────

function StatsBar({ stats }: { stats: ReturnType<typeof useTaskStore>["stats"] }) {
  const items = [
    { label: "Total", value: stats.total, color: "var(--color-gold)" },
    { label: "Pendentes", value: stats.pendente, color: STATUS_COLORS.pendente },
    { label: "Em andamento", value: stats.emAndamento, color: STATUS_COLORS["em-andamento"] },
    { label: "Concluídas", value: stats.concluida, color: STATUS_COLORS.concluida },
    { label: "Atrasadas", value: stats.atrasada, color: STATUS_COLORS.atrasada },
  ];

  const completionPct = stats.total > 0 ? Math.round((stats.concluida / stats.total) * 100) : 0;

  return (
    <div className="flex flex-wrap gap-3 items-center">
      {items.map((item) => (
        <div
          key={item.label}
          className="flex items-center gap-2 px-3 py-2 rounded-lg border border-border/50 bg-surface"
        >
          <div className="w-2 h-2 rounded-full" style={{ backgroundColor: item.color }} />
          <span className="text-xs text-muted-foreground">{item.label}</span>
          <span className="text-sm font-bold text-foreground">{item.value}</span>
        </div>
      ))}
      <div className="flex items-center gap-2 px-3 py-2 rounded-lg border border-gold/30 bg-gold/5 ml-auto">
        <span className="text-xs text-gold">Progresso</span>
        <div className="w-20 h-1.5 rounded-full bg-border overflow-hidden">
          <div
            className="h-full rounded-full bg-gold transition-all"
            style={{ width: `${completionPct}%` }}
          />
        </div>
        <span className="text-sm font-bold text-gold">{completionPct}%</span>
      </div>
    </div>
  );
}

// ─── Completion Filter ──────────────────────────────────────────

type CompletionFilter = "all" | "pending" | "completed";

function CompletionFilterBar({
  value,
  onChange,
}: {
  value: CompletionFilter;
  onChange: (v: CompletionFilter) => void;
}) {
  const options: { id: CompletionFilter; label: string }[] = [
    { id: "all", label: "Todas" },
    { id: "pending", label: "Pendentes" },
    { id: "completed", label: "Concluídas" },
  ];

  return (
    <div className="flex items-center gap-1 bg-surface border border-border/50 rounded-lg p-0.5">
      {options.map((opt) => (
        <button
          key={opt.id}
          onClick={() => onChange(opt.id)}
          className={`text-xs px-3 py-1.5 rounded-md transition-all ${
            value === opt.id
              ? "bg-gold/10 text-gold border border-gold/30"
              : "text-muted-foreground hover:text-foreground border border-transparent"
          }`}
        >
          {opt.label}
        </button>
      ))}
    </div>
  );
}

function applyCompletionFilter(tasks: Task[], filter: CompletionFilter): Task[] {
  if (filter === "pending") return tasks.filter((t) => t.status !== "concluida");
  if (filter === "completed") return tasks.filter((t) => t.status === "concluida");
  return tasks;
}

// ─── Overview View ───────────────────────────────────────────────

function OverviewView({
  tasks,
  onStatusChange,
  onNotesChange,
  onDelete,
  onEdit,
  onToggleComplete,
}: {
  tasks: Task[];
  onStatusChange: (id: number, s: Status) => void;
  onNotesChange: (id: number, notes: string) => void;
  onDelete: (id: number) => void;
  onEdit: (task: Task) => void;
  onToggleComplete: (id: number, currentStatus: Status) => void;
}) {
  const [expandedId, setExpandedId] = useState<number | null>(null);
  const [search, setSearch] = useState("");
  const [filterPriority, setFilterPriority] = useState<Priority | "all">("all");
  const [filterStatus, setFilterStatus] = useState<Status | "all">("all");
  const [sortBy, setSortBy] = useState<"id" | "priority">("id");
  const [completionFilter, setCompletionFilter] = useState<CompletionFilter>("all");

  const filtered = useMemo(() => {
    let result = applyCompletionFilter(tasks, completionFilter);
    if (search) {
      const q = search.toLowerCase();
      result = result.filter(
        (t) =>
          t.title.toLowerCase().includes(q) ||
          t.responsible.some((r) => r.toLowerCase().includes(q)) ||
          t.area.toLowerCase().includes(q)
      );
    }
    if (filterPriority !== "all") result = result.filter((t) => t.priority === filterPriority);
    if (filterStatus !== "all") result = result.filter((t) => t.status === filterStatus);

    if (sortBy === "priority") {
      const order: Record<Priority, number> = { alta: 0, media: 1, baixa: 2 };
      result = [...result].sort((a, b) => order[a.priority] - order[b.priority]);
    }
    return result;
  }, [tasks, search, filterPriority, filterStatus, sortBy, completionFilter]);

  return (
    <div className="space-y-4">
      {/* Completion filter */}
      <div className="flex flex-wrap gap-3 items-center justify-between">
        <CompletionFilterBar value={completionFilter} onChange={setCompletionFilter} />
      </div>

      {/* Filters */}
      <div className="flex flex-wrap gap-3 items-center">
        <div className="relative flex-1 min-w-[200px]">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Buscar tarefa, pessoa ou área..."
            className="w-full pl-9 pr-3 py-2 rounded-lg border border-border/50 bg-surface text-foreground text-sm placeholder:text-muted-foreground focus:ring-1 focus:ring-gold outline-none"
          />
        </div>
        <select
          value={filterPriority}
          onChange={(e) => setFilterPriority(e.target.value as Priority | "all")}
          className="text-xs px-3 py-2 rounded-lg border border-border/50 bg-surface text-foreground"
        >
          <option value="all">Prioridade</option>
          <option value="alta">Alta</option>
          <option value="media">Média</option>
          <option value="baixa">Baixa</option>
        </select>
        <select
          value={filterStatus}
          onChange={(e) => setFilterStatus(e.target.value as Status | "all")}
          className="text-xs px-3 py-2 rounded-lg border border-border/50 bg-surface text-foreground"
        >
          <option value="all">Status</option>
          {(Object.keys(STATUS_LABELS) as Status[]).map((s) => (
            <option key={s} value={s}>
              {STATUS_LABELS[s]}
            </option>
          ))}
        </select>
        <button
          onClick={() => setSortBy((prev) => (prev === "id" ? "priority" : "id"))}
          className="flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground px-3 py-2 rounded-lg border border-border/50 bg-surface"
        >
          <ArrowUpDown size={12} />
          {sortBy === "id" ? "# ID" : "Prioridade"}
        </button>
      </div>

      <div className="text-xs text-muted-foreground">
        {filtered.length} de {tasks.length} tarefas
      </div>

      {/* Task list */}
      {filtered.map((task) => (
        <TaskRow
          key={task.id}
          task={task}
          onStatusChange={onStatusChange}
          onNotesChange={onNotesChange}
          onDelete={onDelete}
          onEdit={onEdit}
          onToggleComplete={onToggleComplete}
          expanded={expandedId === task.id}
          onToggle={() => setExpandedId(expandedId === task.id ? null : task.id)}
        />
      ))}
    </div>
  );
}

// ─── Person View ─────────────────────────────────────────────────

function PersonView({
  tasks,
  onStatusChange,
  onNotesChange,
  onDelete,
  onEdit,
  onToggleComplete,
}: {
  tasks: Task[];
  onStatusChange: (id: number, s: Status) => void;
  onNotesChange: (id: number, notes: string) => void;
  onDelete: (id: number) => void;
  onEdit: (task: Task) => void;
  onToggleComplete: (id: number, currentStatus: Status) => void;
}) {
  const [expandedMember, setExpandedMember] = useState<string | null>(null);
  const [expandedId, setExpandedId] = useState<number | null>(null);
  const [completionFilter, setCompletionFilter] = useState<CompletionFilter>("all");

  const filteredTasks = useMemo(() => applyCompletionFilter(tasks, completionFilter), [tasks, completionFilter]);

  return (
    <div className="space-y-3">
      <CompletionFilterBar value={completionFilter} onChange={setCompletionFilter} />
      {TEAM_MEMBERS.map((member) => {
        const memberTasks = getTasksForMember(filteredTasks, member);
        if (memberTasks.length === 0) return null;
        const done = memberTasks.filter((t) => t.status === "concluida").length;
        const isOpen = expandedMember === member;

        return (
          <div key={member} className="border border-border/50 rounded-lg overflow-hidden">
            <button
              className="w-full flex items-center gap-3 px-4 py-3 hover:bg-surface-elevated/50 transition-colors"
              onClick={() => setExpandedMember(isOpen ? null : member)}
            >
              <User size={16} className="text-gold shrink-0" />
              <span className="text-sm font-semibold text-foreground flex-1 text-left">
                {member}
              </span>
              <span className="text-xs text-muted-foreground">{memberTasks.length} tarefas</span>
              <span className="text-xs text-muted-foreground">{done}/{memberTasks.length}</span>
              {isOpen ? <ChevronDown size={14} className="text-muted-foreground" /> : <ChevronRight size={14} className="text-muted-foreground" />}
            </button>
            {isOpen && (
              <div className="px-2 pb-2">
                {memberTasks.map((task) => (
                  <TaskRow
                    key={task.id}
                    task={task}
                    onStatusChange={onStatusChange}
                    onNotesChange={onNotesChange}
                    onDelete={onDelete}
                    onEdit={onEdit}
                    onToggleComplete={onToggleComplete}
                    expanded={expandedId === task.id}
                    onToggle={() => setExpandedId(expandedId === task.id ? null : task.id)}
                  />
                ))}
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}

// ─── Area View ───────────────────────────────────────────────────

function AreaView({
  tasks,
  onStatusChange,
  onNotesChange,
  onDelete,
  onEdit,
  onToggleComplete,
}: {
  tasks: Task[];
  onStatusChange: (id: number, s: Status) => void;
  onNotesChange: (id: number, notes: string) => void;
  onDelete: (id: number) => void;
  onEdit: (task: Task) => void;
  onToggleComplete: (id: number, currentStatus: Status) => void;
}) {
  const [expandedArea, setExpandedArea] = useState<Area | null>(null);
  const [expandedId, setExpandedId] = useState<number | null>(null);
  const [completionFilter, setCompletionFilter] = useState<CompletionFilter>("all");
  const areas = Object.keys(AREA_LABELS) as Area[];

  const filteredTasks = useMemo(() => applyCompletionFilter(tasks, completionFilter), [tasks, completionFilter]);

  return (
    <div className="space-y-3">
      <CompletionFilterBar value={completionFilter} onChange={setCompletionFilter} />
      {areas.map((area) => {
        const areaTasks = getTasksForArea(filteredTasks, area);
        if (areaTasks.length === 0) return null;
        const done = areaTasks.filter((t) => t.status === "concluida").length;
        const isOpen = expandedArea === area;

        return (
          <div key={area} className="border border-border/50 rounded-lg overflow-hidden">
            <button
              className="w-full flex items-center gap-3 px-4 py-3 hover:bg-surface-elevated/50 transition-colors"
              onClick={() => setExpandedArea(isOpen ? null : area)}
            >
              <div
                className="w-3 h-3 rounded-full shrink-0"
                style={{ backgroundColor: AREA_COLORS[area] }}
              />
              <span className="text-sm font-semibold text-foreground flex-1 text-left">
                {AREA_LABELS[area]}
              </span>
              <span className="text-xs text-muted-foreground">{areaTasks.length} tarefas</span>
              <span className="text-xs text-muted-foreground">{done}/{areaTasks.length}</span>
              {isOpen ? <ChevronDown size={14} className="text-muted-foreground" /> : <ChevronRight size={14} className="text-muted-foreground" />}
            </button>
            {isOpen && (
              <div className="px-2 pb-2">
                {areaTasks.map((task) => (
                  <TaskRow
                    key={task.id}
                    task={task}
                    onStatusChange={onStatusChange}
                    onNotesChange={onNotesChange}
                    onDelete={onDelete}
                    onEdit={onEdit}
                    onToggleComplete={onToggleComplete}
                    expanded={expandedId === task.id}
                    onToggle={() => setExpandedId(expandedId === task.id ? null : task.id)}
                  />
                ))}
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}


// ─── Activity View ───────────────────────────────────────────────

function ActivityView() {
  const { activities, isLoading } = useActivityFeed();

  const actionLabels: Record<string, string> = {
    status_change: "alterou o status",
    notes_update: "atualizou as notas",
    task_created: "criou a tarefa",
    task_deleted: "removeu a tarefa",
  };

  const getActionLabel = (action: string) => {
    if (action.startsWith("field_update:")) {
      const field = action.replace("field_update:", "");
      return `editou ${field}`;
    }
    return actionLabels[action] || action;
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="animate-spin w-6 h-6 border-2 border-gold border-t-transparent rounded-full" />
      </div>
    );
  }

  if (activities.length === 0) {
    return (
      <div className="text-center py-12">
        <Activity size={32} className="mx-auto text-muted-foreground mb-3" />
        <p className="text-sm text-muted-foreground">Nenhuma atividade registrada ainda.</p>
        <p className="text-xs text-muted-foreground mt-1">
          As alterações feitas nas tarefas aparecerão aqui em tempo real.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-2">
      <h3 className="text-sm font-semibold text-gold uppercase tracking-wider flex items-center gap-2 mb-4">
        <Activity size={14} />
        Feed de Atividade
      </h3>
      {activities.map((a) => (
        <div
          key={a.id}
          className="flex items-start gap-3 px-4 py-3 border border-border/30 rounded-lg bg-surface/30"
        >
          <div className="w-8 h-8 rounded-full bg-gold/10 border border-gold/20 flex items-center justify-center shrink-0 mt-0.5">
            <span className="text-xs font-bold text-gold">
              {a.userName.charAt(0).toUpperCase()}
            </span>
          </div>
          <div className="flex-1 min-w-0">
            <div className="text-sm">
              <span className="font-semibold text-foreground">{a.userName}</span>{" "}
              <span className="text-muted-foreground">{getActionLabel(a.action)}</span>
            </div>
            {a.taskTitle && (
              <div className="text-xs text-gold mt-0.5 truncate">
                #{String(a.taskId).padStart(2, "0")} {a.taskTitle}
              </div>
            )}
            {a.action === "status_change" && a.oldValue && a.newValue && (
              <div className="text-xs text-muted-foreground mt-1">
                <span style={{ color: STATUS_COLORS[a.oldValue as Status] || undefined }}>
                  {STATUS_LABELS[a.oldValue as Status] || a.oldValue}
                </span>
                {" → "}
                <span style={{ color: STATUS_COLORS[a.newValue as Status] || undefined }}>
                  {STATUS_LABELS[a.newValue as Status] || a.newValue}
                </span>
              </div>
            )}
            <div className="text-[10px] text-muted-foreground/60 mt-1">
              {new Date(a.createdAt).toLocaleString("pt-BR")}
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}

// ─── Meetings View ──────────────────────────────────────────────

function MeetingsView({ userName }: { userName: string }) {
  const utils = trpc.useUtils();
  const { data: meetings, isLoading } = trpc.meetings.list.useQuery();
  const uploadMut = trpc.meetings.create.useMutation({
    onSuccess: () => {
      utils.meetings.list.invalidate();
      toast.success("Documento enviado com sucesso!");
    },
    onError: (err) => {
      toast.error("Erro ao enviar: " + err.message);
    },
  });
  const deleteMut = trpc.meetings.delete.useMutation({
    onSuccess: () => {
      utils.meetings.list.invalidate();
      toast.success("Documento removido");
    },
  });

  const [showUpload, setShowUpload] = useState(false);
  const [uploadTitle, setUploadTitle] = useState("");
  const [uploadDate, setUploadDate] = useState("");
  const [uploadType, setUploadType] = useState<"pauta" | "resumo" | "outro">("pauta");
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleUpload = useCallback(async () => {
    if (!selectedFile || !uploadTitle.trim() || !uploadDate.trim()) {
      toast.error("Preencha todos os campos e selecione um arquivo");
      return;
    }

    // Read file as base64
    const reader = new FileReader();
    reader.onload = () => {
      const base64 = (reader.result as string).split(",")[1];
      uploadMut.mutate({
        title: uploadTitle,
        meetingDate: uploadDate,
        fileType: uploadType,
        fileName: selectedFile.name,
        fileBase64: base64,
        contentType: selectedFile.type || "application/pdf",
        uploadedBy: userName,
      });
      setShowUpload(false);
      setUploadTitle("");
      setUploadDate("");
      setUploadType("pauta");
      setSelectedFile(null);
    };
    reader.readAsDataURL(selectedFile);
  }, [selectedFile, uploadTitle, uploadDate, uploadType, userName, uploadMut]);

  const fileTypeLabels: Record<string, string> = {
    pauta: "Pauta",
    resumo: "Resumo",
    outro: "Outro",
  };

  const fileTypeColors: Record<string, string> = {
    pauta: "#f59e0b",
    resumo: "#10b981",
    outro: "#6b7280",
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="animate-spin w-6 h-6 border-2 border-gold border-t-transparent rounded-full" />
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-semibold text-gold uppercase tracking-wider flex items-center gap-2">
          <FileText size={14} />
          Documentos de Reuniões
        </h3>
        <Button
          size="sm"
          onClick={() => setShowUpload(true)}
          className="bg-gold text-background hover:bg-gold/90 text-xs gap-1"
        >
          <Upload size={12} />
          Enviar Documento
        </Button>
      </div>

      {/* Upload Dialog */}
      {showUpload && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-surface border border-border rounded-2xl max-w-md w-full p-6 space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-bold text-foreground flex items-center gap-2">
                <Upload size={18} className="text-gold" />
                Enviar Documento
              </h2>
              <button onClick={() => setShowUpload(false)} className="text-muted-foreground hover:text-foreground">
                <X size={18} />
              </button>
            </div>

            <div className="space-y-3">
              <div>
                <label className="text-xs text-muted-foreground block mb-1">Título *</label>
                <input
                  value={uploadTitle}
                  onChange={(e) => setUploadTitle(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-border bg-background text-foreground text-sm focus:ring-1 focus:ring-gold outline-none"
                  placeholder="Ex: Pauta Reunião 13/02/2026"
                />
              </div>

              <div>
                <label className="text-xs text-muted-foreground block mb-1">Data da Reunião *</label>
                <input
                  type="date"
                  value={uploadDate}
                  onChange={(e) => setUploadDate(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-border bg-background text-foreground text-sm focus:ring-1 focus:ring-gold outline-none"
                />
              </div>

              <div>
                <label className="text-xs text-muted-foreground block mb-1">Tipo</label>
                <select
                  value={uploadType}
                  onChange={(e) => setUploadType(e.target.value as "pauta" | "resumo" | "outro")}
                  className="w-full px-3 py-2 rounded-lg border border-border bg-background text-foreground text-sm focus:ring-1 focus:ring-gold outline-none"
                >
                  <option value="pauta">Pauta</option>
                  <option value="resumo">Resumo / Ata</option>
                  <option value="outro">Outro</option>
                </select>
              </div>

              <div>
                <label className="text-xs text-muted-foreground block mb-1">Arquivo (PDF) *</label>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept=".pdf,.doc,.docx,.txt,.md"
                  onChange={(e) => setSelectedFile(e.target.files?.[0] || null)}
                  className="hidden"
                />
                <button
                  onClick={() => fileInputRef.current?.click()}
                  className="w-full px-3 py-4 rounded-lg border-2 border-dashed border-border bg-background text-sm text-muted-foreground hover:border-gold/50 transition-colors flex items-center justify-center gap-2"
                >
                  {selectedFile ? (
                    <>
                      <FileText size={16} className="text-gold" />
                      <span className="text-foreground">{selectedFile.name}</span>
                      <span className="text-xs text-muted-foreground">
                        ({(selectedFile.size / 1024).toFixed(0)} KB)
                      </span>
                    </>
                  ) : (
                    <>
                      <Upload size={16} />
                      Clique para selecionar arquivo
                    </>
                  )}
                </button>
              </div>
            </div>

            <div className="flex gap-2 pt-2">
              <Button variant="outline" onClick={() => setShowUpload(false)} className="flex-1">
                Cancelar
              </Button>
              <Button
                onClick={handleUpload}
                disabled={uploadMut.isPending}
                className="flex-1 bg-gold text-background hover:bg-gold/90"
              >
                {uploadMut.isPending ? (
                  <div className="animate-spin w-4 h-4 border-2 border-background border-t-transparent rounded-full" />
                ) : (
                  "Enviar"
                )}
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Meetings list */}
      {(!meetings || meetings.length === 0) ? (
        <div className="text-center py-12">
          <FileText size={32} className="mx-auto text-muted-foreground mb-3" />
          <p className="text-sm text-muted-foreground">Nenhum documento de reunião ainda.</p>
          <p className="text-xs text-muted-foreground mt-1">
            Envie pautas e resumos de reuniões para que toda a equipe possa acessar.
          </p>
        </div>
      ) : (
        <div className="space-y-2">
          {meetings.map((m) => (
            <div
              key={m.id}
              className="flex items-center gap-4 px-4 py-3 border border-border/50 rounded-lg bg-surface/30 hover:bg-surface-elevated/30 transition-colors"
            >
              <div className="w-10 h-10 rounded-lg bg-gold/10 border border-gold/20 flex items-center justify-center shrink-0">
                <FileText size={20} className="text-gold" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-sm font-medium text-foreground truncate">{m.title}</div>
                <div className="flex items-center gap-3 mt-0.5">
                  <span className="text-xs text-muted-foreground flex items-center gap-1">
                    <Calendar size={10} />
                    {m.meetingDate}
                  </span>
                  <span
                    className="text-[10px] px-1.5 py-0.5 rounded font-medium uppercase"
                    style={{
                      color: fileTypeColors[m.fileType],
                      backgroundColor: `${fileTypeColors[m.fileType]}18`,
                      border: `1px solid ${fileTypeColors[m.fileType]}30`,
                    }}
                  >
                    {fileTypeLabels[m.fileType]}
                  </span>
                  <span className="text-[10px] text-muted-foreground">
                    por {m.uploadedBy}
                  </span>
                </div>
              </div>
              <div className="flex items-center gap-2 shrink-0">
                <a
                  href={m.fileUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-xs text-gold hover:text-gold/80 flex items-center gap-1 px-3 py-1.5 rounded-lg border border-gold/30 bg-gold/5 transition-colors"
                >
                  <Eye size={12} />
                  Abrir
                </a>
                <a
                  href={m.fileUrl}
                  download={m.fileName}
                  className="text-xs text-muted-foreground hover:text-foreground flex items-center gap-1 px-3 py-1.5 rounded-lg border border-border/50 bg-surface transition-colors"
                >
                  <Download size={12} />
                </a>
                <button
                  onClick={() => {
                    if (confirm("Remover este documento?")) {
                      deleteMut.mutate({ id: m.id });
                    }
                  }}
                  className="text-xs text-destructive hover:text-destructive/80 p-1.5"
                >
                  <Trash2 size={12} />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ─── Export function ─────────────────────────────────────────────

function exportTasks(tasks: Task[]) {
  let text = "TAREFAS MR. LION\n";
  text += "=".repeat(50) + "\n\n";

  const byPerson: Record<string, Task[]> = {};
  tasks.forEach((t) => {
    t.responsible.forEach((r) => {
      if (!byPerson[r]) byPerson[r] = [];
      byPerson[r].push(t);
    });
  });

  Object.entries(byPerson).forEach(([person, pTasks]) => {
    text += `\n${person.toUpperCase()}\n`;
    text += "-".repeat(30) + "\n";
    pTasks.forEach((t) => {
      const statusEmoji =
        t.status === "concluida" ? "✅" : t.status === "em-andamento" ? "🔄" : t.status === "atrasada" ? "⚠️" : "⬜";
      text += `${statusEmoji} #${String(t.id).padStart(2, "0")} ${t.title}\n`;
      if (t.notes) text += `   📝 ${t.notes}\n`;
    });
  });

  navigator.clipboard.writeText(text).then(() => {
    toast.success("Tarefas copiadas para a área de transferência!");
  });
}

// ─── Main Tasks Page ─────────────────────────────────────────────

export default function Tasks() {
  const { userName, setUserName, hasName } = useUserName();
  const onlineUsers = usePresence(userName);
  const { tasks, isLoading, updateTaskStatus, updateTaskNotes, createTask, editTask, removeTask, stats } =
    useTaskStore(userName);
  const [activeTab, setActiveTab] = useState<ViewTab>("overview");
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [editingTask, setEditingTask] = useState<Task | null>(null);

  const handleToggleComplete = useCallback(
    (id: number, currentStatus: Status) => {
      if (currentStatus === "concluida") {
        updateTaskStatus(id, "pendente");
      } else {
        updateTaskStatus(id, "concluida");
        fireCelebration();
        toast.success("Tarefa concluída! 🎉", {
          duration: 2000,
        });
      }
    },
    [updateTaskStatus]
  );

  const handleEditSave = useCallback(
    (id: number, data: Partial<Task>) => {
      editTask(id, data);
    },
    [editTask]
  );

  if (!hasName) {
    return <UserNamePrompt onSubmit={setUserName} />;
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center space-y-4">
          <div className="animate-spin w-8 h-8 border-2 border-gold border-t-transparent rounded-full mx-auto" />
          <p className="text-sm text-muted-foreground">Carregando tarefas...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border/50 bg-surface/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div>
                <h1 className="text-lg font-bold text-foreground tracking-tight">
                  <span className="text-gold">MR. LION</span> — Gestão de Tarefas
                </h1>
                <div className="flex items-center gap-3 mt-0.5">
                  <p className="text-xs text-muted-foreground">
                    {stats.total} tarefas · {stats.concluida} concluídas
                  </p>
                  <PresenceBar users={onlineUsers} />
                </div>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-gold/20 bg-gold/5">
                <User size={12} className="text-gold" />
                <span className="text-xs text-gold font-medium">{userName}</span>
              </div>
              <Button
                size="sm"
                variant="outline"
                className="text-xs gap-1"
                onClick={() => setShowCreateDialog(true)}
              >
                <Plus size={12} />
                Nova
              </Button>
              <Button
                size="sm"
                variant="outline"
                className="text-xs gap-1"
                onClick={() => exportTasks(tasks)}
              >
                <Download size={12} />
                Exportar
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Stats */}
      <div className="container py-4">
        <StatsBar stats={stats} />
      </div>

      {/* Tabs */}
      <div className="container">
        <div className="flex gap-1 border-b border-border/50 mb-4 overflow-x-auto">
          {TABS.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-4 py-2.5 text-sm font-medium transition-colors border-b-2 whitespace-nowrap ${
                activeTab === tab.id
                  ? "text-gold border-gold"
                  : "text-muted-foreground border-transparent hover:text-foreground"
              }`}
            >
              {tab.icon}
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Content */}
      <div className="container pb-12">
        {activeTab === "overview" && (
          <OverviewView
            tasks={tasks}
            onStatusChange={updateTaskStatus}
            onNotesChange={updateTaskNotes}
            onDelete={removeTask}
            onEdit={setEditingTask}
            onToggleComplete={handleToggleComplete}
          />
        )}
        {activeTab === "person" && (
          <PersonView
            tasks={tasks}
            onStatusChange={updateTaskStatus}
            onNotesChange={updateTaskNotes}
            onDelete={removeTask}
            onEdit={setEditingTask}
            onToggleComplete={handleToggleComplete}
          />
        )}
        {activeTab === "area" && (
          <AreaView
            tasks={tasks}
            onStatusChange={updateTaskStatus}
            onNotesChange={updateTaskNotes}
            onDelete={removeTask}
            onEdit={setEditingTask}
            onToggleComplete={handleToggleComplete}
          />
        )}
        {activeTab === "activity" && <ActivityView />}
        {activeTab === "meetings" && <MeetingsView userName={userName} />}
      </div>

      {/* Create Dialog */}
      {showCreateDialog && (
        <CreateTaskDialog
          onClose={() => setShowCreateDialog(false)}
          onCreate={createTask}
        />
      )}

      {/* Edit Dialog */}
      {editingTask && (
        <EditTaskDialog
          task={editingTask}
          onClose={() => setEditingTask(null)}
          onSave={handleEditSave}
        />
      )}
    </div>
  );
}
