export type Phase = "running" | "pending" | "ideation";
export type Priority = "alta" | "media" | "baixa";
export type TopicStatus = "waiting" | "active" | "completed" | "parked";

export interface Dependency {
  targetId: string;
  label: string;
  description: string;
}

export interface Topic {
  id: string;
  number: string;
  title: string;
  parentBlock: string;
  phase: Phase;
  phaseLabel: string;
  priority: Priority;
  priorityJustification: string;
  timeMinutes: number;
  decision: string;
  dependencies: Dependency[];
}

export interface MeetingBlock {
  id: string;
  order: number;
  title: string;
  priority: Priority;
  timeMinutes: number;
  topics: Topic[];
}

export const TOTAL_MEETING_MINUTES = 80;

export const PARTICIPANTS = ["Luca", "João", "Luan", "Guilherme"];

export const PRIORITY_LEGEND: Record<Priority, string> = {
  alta: "Impacto direto no faturamento ou bloqueio operacional nos próximos 30 dias.",
  media: "Importante para o trimestre, mas sem urgência imediata de faturamento.",
  baixa: "Projeto de longo prazo ou melhoria contínua, sem impacto crítico se adiado.",
};

export const PHASE_CONFIG: Record<Phase, { emoji: string; label: string; color: string }> = {
  running: { emoji: "🟢", label: "Em andamento", color: "var(--color-phase-green)" },
  pending: { emoji: "🟡", label: "Pendente de aprovação", color: "var(--color-phase-yellow)" },
  ideation: { emoji: "🔴", label: "Ideação", color: "var(--color-phase-red)" },
};

export const INTRO_POINTS = [
  "E-commerce parado: nova loja Nuvemshop pronta mas inoperante — Mercado Pago, domínio e pixel ainda pendentes.",
  "Sem estratégia de Carnaval definida a menos de 2 semanas do evento.",
  "Área comercial sem estrutura: sem equipe dedicada, sem material de apoio (Kit PDV) e sem prospecção ativa de distribuidores.",
  "Programa de revendedores (Mr. Lion Nation) travado pela falta da plataforma de e-commerce.",
  "Press-kits prontos mas nunca enviados para influenciadores e artistas.",
  "Conteúdos de divulgação do WhatsApp de vendas ainda sem alinhamento final.",
  "Delivery ainda não validado operacionalmente.",
  "Integração WooCommerce/Bling com falhas — vários pedidos não sendo puxados ou puxados em status errado.",
  "Bot SDR em processo de configuração no HighLevel, porém existe contato alternativo a ser avaliado.",
  "Automação de WhatsApp (suporte) configurada na Nuvemshop mas nunca testada.",
];

export interface Pendencia {
  number: number;
  text: string;
  status: "pendente" | "parcial" | "pronto";
}

export const NUVEMSHOP_PENDENCIAS: Pendencia[] = [
  { number: 1, text: "Configurar o Mercado Pago.", status: "pendente" },
  { number: 2, text: "Configuração do domínio ainda não foi feita para não derrubar o site atual.", status: "pendente" },
  { number: 3, text: "Preços PJ configurados com base no Nível 1 da tabela PJ (plataforma não suporta modelo por níveis, só desconto padrão).", status: "parcial" },
  { number: 4, text: "Pixel e tags do Google Ads e Meta serão configurados só depois que tudo estiver resolvido, pra não atrapalhar o tráfego do site atual.", status: "pendente" },
  { number: 5, text: "Melhor Envio e Bling já integrados, mas precisam ser testados. Nuvem Envio também habilitado.", status: "parcial" },
  { number: 6, text: "Bot de suporte configurado e integrado com a Nuvemshop, mas não ativado para não gerar conflito com a loja antiga.", status: "parcial" },
];

export interface PontoDecisorio {
  title: string;
  context: string;
  options: string[];
  topicId: string;
}

export const PONTOS_DECISORIOS: PontoDecisorio[] = [
  {
    title: "Automação WhatsApp (Suporte)",
    context: "Bot de suporte já configurado e integrado com a Nuvemshop, porém nunca testado. Alivia gargalo de atendimento/suporte.",
    options: ["Ativar e testar na nova loja antes da migração", "Aguardar migração completa para ativar"],
    topicId: "1a",
  },
  {
    title: "Bot SDR (HighLevel)",
    context: "Bot SDR em processo de configuração no HighLevel, porém João tem um contato de alguém que faz. Avaliar qual caminho tomar.",
    options: ["Continuar configuração interna no HighLevel", "Avaliar o contato do João e terceirizar"],
    topicId: "4a",
  },
  {
    title: "Falha Integração WooCommerce/Bling",
    context: "Vários pedidos não estão sendo puxados ou estão sendo puxados em status errado. Problema recorrente que afeta a operação.",
    options: ["Resolver migrando para a Nuvemshop (já integrada com Bling)", "Refazer a integração WooCommerce/Bling"],
    topicId: "1a",
  },
];

export interface ImportantDate {
  date: string;
  name: string;
  note: string;
  priority: "alta" | "media" | "baixa";
}

export interface MonthDates {
  month: string;
  dates: ImportantDate[];
}

export const IMPORTANT_DATES: MonthDates[] = [
  {
    month: "Fevereiro",
    dates: [
      { date: "Variável", name: "Carnaval", note: "Maior potencial do mês. Presença em blocos/festas, drinks temáticos.", priority: "alta" },
      { date: "14", name: "Valentine's Day", note: "Relevante se houver público internacional ou posicionamento aspiracional.", priority: "baixa" },
    ],
  },
  {
    month: "Março",
    dates: [
      { date: "8", name: "Dia da Mulher", note: "Drinks com perfil mais leve, collabs com influenciadoras.", priority: "media" },
      { date: "15", name: "Dia do Consumidor", note: "Promoções no e-commerce, cupons, frete grátis.", priority: "alta" },
    ],
  },
  {
    month: "Abril",
    dates: [
      { date: "Variável", name: "Páscoa", note: "Kits presenteáveis, harmonização whisky + chocolate.", priority: "media" },
      { date: "7", name: "Dia da Cerveja", note: "Conteúdo provocativo: 'troque a cerveja por whisky'.", priority: "baixa" },
      { date: "21", name: "Tiradentes", note: "Feriado prolongado, conteúdo lifestyle/viagem.", priority: "baixa" },
    ],
  },
  {
    month: "Maio",
    dates: [
      { date: "1", name: "Dia do Trabalhador", note: "Feriado, conteúdo de lifestyle/relaxamento.", priority: "baixa" },
      { date: "2º dom.", name: "Dia das Mães", note: "Kits presente, ângulo 'presenteie quem merece'.", priority: "alta" },
      { date: "3º sáb.", name: "Dia Mundial do Whisky", note: "Data obrigatória. Maior oportunidade de branding do ano: conteúdo educativo, degustações, lançamentos.", priority: "alta" },
    ],
  },
  {
    month: "Junho",
    dates: [
      { date: "11+", name: "Copa do Mundo (Grupos)", note: "Kits 'assista o jogo com Mr. Lion', promoções em bares parceiros, drinks com nome de seleção, collabs com influenciadores esportivos.", priority: "alta" },
      { date: "12", name: "Dia dos Namorados", note: "Compete com a estreia da Copa. Antecipar campanha para a semana anterior. Kits para casal, embalagens especiais.", priority: "alta" },
      { date: "19", name: "Dia Mundial do Cocktail", note: "Receitas, conteúdo bartender.", priority: "baixa" },
      { date: "Variável", name: "Festas Juninas", note: "Ficam em segundo plano por causa da Copa. Drinks com canela, gengibre, especiarias.", priority: "baixa" },
      { date: "28", name: "Dia do Orgulho LGBTQ+", note: "Posicionamento inclusivo se alinhado com a marca.", priority: "baixa" },
    ],
  },
  {
    month: "Julho",
    dates: [
      { date: "Até 19", name: "Copa do Mundo (Eliminatórias/Final)", note: "Se o Brasil avançar, intensificar ações. Promoção 'a cada vitória, desconto de X%'. Kits para assistir em grupo. Conteúdo watch party.", priority: "alta" },
      { date: "20", name: "Dia do Amigo", note: "Cai 1 dia depois da final. Campanha pós-Copa 'celebre com os amigos que estiveram junto'. Kits para dividir, promoção 'leve 2'.", priority: "media" },
      { date: "Mês", name: "Férias de Inverno", note: "Campanha de consumo em casa, noites frias, whisky puro.", priority: "media" },
    ],
  },
  {
    month: "Agosto",
    dates: [
      { date: "4", name: "Dia do Barman", note: "Conteúdo com bartenders, receitas autorais, valorização do ofício.", priority: "media" },
      { date: "2º dom.", name: "Dia dos Pais", note: "Alta prioridade. Junto com Namorados, maior potencial para venda de kits presente.", priority: "alta" },
      { date: "13", name: "Dia da Cachaça", note: "Conteúdo comparativo ou colaborativo com a cultura de destilados brasileiros.", priority: "baixa" },
    ],
  },
  {
    month: "Setembro",
    dates: [
      { date: "7", name: "Independência do Brasil", note: "Conteúdo patriótico: 'whisky feito no Brasil com orgulho'.", priority: "media" },
      { date: "15", name: "Dia do Cliente", note: "Promoções, recompensas para clientes recorrentes, programa de fidelidade.", priority: "alta" },
      { date: "22", name: "Início da Primavera", note: "Transição para drinks mais leves, highballs, lançamento de sabores.", priority: "baixa" },
    ],
  },
  {
    month: "Outubro",
    dates: [
      { date: "12", name: "Dia das Crianças", note: "Feriado prolongado gera consumo social (não é oportunidade direta).", priority: "baixa" },
      { date: "31", name: "Halloween", note: "Drinks temáticos, embalagens edição limitada, conteúdo criativo.", priority: "media" },
      { date: "Variável", name: "Oktoberfest", note: "Conteúdo 'além da cerveja', posicionamento alternativo.", priority: "baixa" },
    ],
  },
  {
    month: "Novembro",
    dates: [
      { date: "20", name: "Consciência Negra", note: "Conteúdo de valorização cultural se alinhado com a marca.", priority: "baixa" },
      { date: "4ª sexta", name: "Black Friday", note: "Maior data de e-commerce do ano. Descontos, kits exclusivos, bundles.", priority: "alta" },
      { date: "Pós-BF", name: "Cyber Monday", note: "Extensão de promoções online.", priority: "media" },
    ],
  },
  {
    month: "Dezembro",
    dates: [
      { date: "Mês", name: "Confraternizações", note: "Prospecção de vendas corporativas, kits empresa.", priority: "alta" },
      { date: "21", name: "Início do Verão", note: "Retomada de campanha de drinks refrescantes.", priority: "baixa" },
      { date: "25", name: "Natal", note: "Kits presente premium, embalagens especiais, collabs de fim de ano.", priority: "alta" },
      { date: "31", name: "Réveillon", note: "Campanhas de brinde, presença em festas, conteúdo aspiracional.", priority: "alta" },
    ],
  },
];

export const TRANSVERSAL_DATES = [
  "Jogos do UFC com Carlos Prates — se a collab avançar, cada luta é uma ação.",
  "Lançamentos musicais do Orochi — se a collab sair, cada clipe/álbum é oportunidade.",
  "Finais de campeonatos (futebol, UFC, F1) — conteúdo 'assista com Mr. Lion'.",
];

export const meetingBlocks: MeetingBlock[] = [
  {
    id: "block-0",
    order: 0,
    title: "Introdução",
    priority: "alta",
    timeMinutes: 5,
    topics: [
      {
        id: "0a",
        number: "0a",
        title: "Panorama Geral",
        parentBlock: "Introdução",
        phase: "ideation",
        phaseLabel: "Ideação",
        priority: "alta",
        priorityJustification: "Alinhamento inicial sobre os principais gargalos e oportunidades da empresa antes de entrar nos tópicos.",
        timeMinutes: 5,
        decision: "Alinhar a equipe sobre o estado atual da empresa e garantir que todos entendam as prioridades da reunião.",
        dependencies: [],
      },
    ],
  },
  {
    id: "block-1",
    order: 1,
    title: "Operações e Vendas (E-commerce)",
    priority: "alta",
    timeMinutes: 25,
    topics: [
      {
        id: "1a",
        number: "1a",
        title: "Nuvemshop",
        parentBlock: "Operações e Vendas",
        phase: "pending",
        phaseLabel: "Pendente de aprovação",
        priority: "alta",
        priorityJustification: "Bloqueio operacional. A nova loja está pronta, mas inoperante devido a 6 pendências técnicas. Além disso, a integração atual WooCommerce/Bling apresenta falhas críticas.",
        timeMinutes: 15,
        decision: "Definir os responsáveis e prazos finais para cada pendência técnica. Decidir se resolve a falha WooCommerce/Bling com a migração ou refazendo a integração.",
        dependencies: [],
      },
      {
        id: "1b",
        number: "1b",
        title: "Delivery",
        parentBlock: "Operações e Vendas",
        phase: "pending",
        phaseLabel: "Pendente de aprovação",
        priority: "media",
        priorityJustification: "Novo canal de vendas com baixo custo de entrada, mas que precisa de validação operacional antes de escalar.",
        timeMinutes: 10,
        decision: "Definir a data de início do soft launch e os responsáveis por acompanhar a operação e os testes de entrega.",
        dependencies: [],
      },
    ],
  },
  {
    id: "block-2",
    order: 2,
    title: "Marketing e Conteúdo",
    priority: "alta",
    timeMinutes: 25,
    topics: [
      {
        id: "2a",
        number: "2a",
        title: "Conteúdos Fev. e Carnaval",
        parentBlock: "Marketing e Conteúdo",
        phase: "ideation",
        phaseLabel: "Ideação",
        priority: "alta",
        priorityJustification: "Urgência de calendário. O Carnaval está próximo e ainda não há uma estratégia de conteúdo definida.",
        timeMinutes: 15,
        decision: "Brainstorm e definição de ações de marketing para o Carnaval. Validar o cronograma de conteúdo para o restante de Fevereiro.",
        dependencies: [],
      },
      {
        id: "2b",
        number: "2b",
        title: "Datas Importantes do Ano",
        parentBlock: "Marketing e Conteúdo",
        phase: "ideation",
        phaseLabel: "Ideação",
        priority: "baixa",
        priorityJustification: "Planejamento de longo prazo. Listar datas como Dia dos Namorados, Dia dos Pais, Dia do Whisky, Natal, Ano Novo etc.",
        timeMinutes: 5,
        decision: "Listar todas as datas importantes do ano e definir quais terão ações de marketing ou promoções dedicadas.",
        dependencies: [],
      },
      {
        id: "2c",
        number: "2c",
        title: "Press-kit",
        parentBlock: "Marketing e Conteúdo",
        phase: "pending",
        phaseLabel: "Pendente de aprovação",
        priority: "media",
        priorityJustification: "A empresa possui press-kits prontos, mas ainda não houve o envio para influenciadores e cantores.",
        timeMinutes: 5,
        decision: "Definir uma lista de influenciadores e artistas estratégicos para o envio dos kits e planejar a logística de distribuição.",
        dependencies: [],
      },
    ],
  },
  {
    id: "block-3",
    order: 3,
    title: "Projetos Estratégicos (Collabs)",
    priority: "alta",
    timeMinutes: 10,
    topics: [
      {
        id: "3a",
        number: "3a",
        title: "Garrafa Orochi",
        parentBlock: "Projetos Estratégicos",
        phase: "running",
        phaseLabel: "Em andamento",
        priority: "alta",
        priorityJustification: "Collab de alto impacto com faturamento direto e cronograma já em andamento para Março.",
        timeMinutes: 5,
        decision: "Alinhar o plano de marketing de lançamento.",
        dependencies: [],
      },
      {
        id: "3b",
        number: "3b",
        title: "Mr. Lion Nation",
        parentBlock: "Projetos Estratégicos",
        phase: "pending",
        phaseLabel: "Pendente de aprovação",
        priority: "alta",
        priorityJustification: "Canal de receita com demanda orgânica validada (60% dos leads) e que pode ser destravado com a nova plataforma.",
        timeMinutes: 5,
        decision: "Aprovar a estruturação do programa. Definir o modelo, o kit inicial, as margens e a estratégia de lançamento.",
        dependencies: [
          {
            targetId: "1a",
            label: "Nuvemshop (1a)",
            description: "O programa de revendedores só pode ser lançado após a plataforma de e-commerce estar 100% funcional.",
          },
        ],
      },
      {
        id: "3c",
        number: "3c",
        title: "Garrafa Carlos Prates",
        parentBlock: "Projetos Estratégicos",
        phase: "ideation",
        phaseLabel: "Ideação",
        priority: "baixa",
        priorityJustification: "Lutador de UFC que já demonstrou interesse na marca, mas nunca houve uma proposta formal.",
        timeMinutes: 0,
        decision: "Avaliar se vale formalizar uma proposta de collab com Carlos Prates.",
        dependencies: [],
      },
    ],
  },
  {
    id: "block-4",
    order: 4,
    title: "Comercial e Expansão",
    priority: "alta",
    timeMinutes: 10,
    topics: [
      {
        id: "4a",
        number: "4a",
        title: "Estruturação Comercial",
        parentBlock: "Comercial e Expansão",
        phase: "ideation",
        phaseLabel: "Ideação",
        priority: "alta",
        priorityJustification: "A falta de presença em pontos de venda físicos é apontada como a maior dificuldade da marca. Bot SDR em configuração no HighLevel, mas há alternativa a avaliar.",
        timeMinutes: 10,
        decision: "Discutir a contratação de uma equipe comercial vs. reestruturação da área. Avaliar se continua com HighLevel ou usa o contato do João para o bot SDR.",
        dependencies: [
          {
            targetId: "5a",
            label: "Kit PDV (5a)",
            description: "A equipe comercial precisa de material de apoio (Kit PDV) para iniciar a prospecção.",
          },
        ],
      },
    ],
  },
  {
    id: "block-5",
    order: 5,
    title: "Branding e Produto",
    priority: "media",
    timeMinutes: 5,
    topics: [
      {
        id: "5a",
        number: "5a",
        title: "Kit PDV",
        parentBlock: "Branding e Produto",
        phase: "pending",
        phaseLabel: "Pendente de aprovação",
        priority: "media",
        priorityJustification: "Ferramenta de apoio essencial para a área comercial, mas sua urgência está atrelada à estruturação do time.",
        timeMinutes: 5,
        decision: "Definir o formato final e conteúdo do Kit PDV. Material deve ser simples, direto e de fácil envio para prospecção comercial.",
        dependencies: [],
      },
      {
        id: "5b",
        number: "5b",
        title: "Garrafa Nova Mr. Lion",
        parentBlock: "Branding e Produto",
        phase: "ideation",
        phaseLabel: "Ideação",
        priority: "baixa",
        priorityJustification: "Md tem uma dor com a garrafa atual, mas é um projeto de longo prazo sem impacto imediato.",
        timeMinutes: 0,
        decision: "Discutir se vale iniciar o processo de redesign da garrafa.",
        dependencies: [],
      },
      {
        id: "5c",
        number: "5c",
        title: "RTD (Ready-to-Drink)",
        parentBlock: "Branding e Produto",
        phase: "ideation",
        phaseLabel: "Ideação",
        priority: "baixa",
        priorityJustification: "Tendência de mercado com potencial, mas ainda em fase de pesquisa inicial.",
        timeMinutes: 0,
        decision: "Avaliar viabilidade e interesse em desenvolver uma linha RTD.",
        dependencies: [],
      },
    ],
  },
];

export const allTopics: Topic[] = meetingBlocks.flatMap((b) => b.topics);

// No more LOW_PRIORITY_ITEMS — all items are now navigable topics

// Dependency connections for the visual map
export const DEPENDENCY_CONNECTIONS = [
  {
    from: "1a",
    fromLabel: "Nuvemshop",
    to: "3b",
    toLabel: "Mr. Lion Nation",
    type: "destrava" as const,
    label: "destrava",
  },
  {
    from: "5a",
    fromLabel: "Kit PDV",
    to: "4a",
    toLabel: "Estr. Comercial",
    type: "apoia" as const,
    label: "apoia",
  },
];
