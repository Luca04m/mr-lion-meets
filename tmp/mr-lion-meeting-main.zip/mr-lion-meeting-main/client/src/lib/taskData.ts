// Task Management Data — Mr. Lion — Reunião 13/02/2026
// All 39 tasks with corrections from Part 1

export type Priority = "alta" | "media" | "baixa";
export type Status = "pendente" | "em-andamento" | "concluida" | "atrasada";
export type Area =
  | "nuvemshop"
  | "carnaval"
  | "orochi"
  | "nation"
  | "carlos-prates"
  | "comercial"
  | "kit-pdv"
  | "garrafa-nova"
  | "rtd"
  | "conteudo"
  | "produtos"
  | "marketing"
  | "press-kit";

export interface Task {
  id: number;
  title: string;
  detail: string;
  responsible: string[];

  priority: Priority;
  area: Area;
  status: Status;
  dependencies: number[];
  notes: string;
  decision: string | null;
}

export interface Decision {
  id: string;
  title: string;
  context: string;
}

export interface Dependency {
  from: string;
  to: string;
  label: string;
}

export const TEAM_MEMBERS = ["Luca", "João", "Luhan", "Pedro", "Guilherme"] as const;

export const AREA_LABELS: Record<Area, string> = {
  nuvemshop: "Nuvemshop e E-commerce",
  carnaval: "Carnaval",
  orochi: "Garrafa Orochi",
  nation: "Mr. Lion Nation",
  "carlos-prates": "Carlos Prates",
  comercial: "Comercial e Processos",
  "kit-pdv": "Kit PDV",
  "garrafa-nova": "Garrafa Nova e Rebranding",
  rtd: "RTD (Ready-to-Drink)",
  conteudo: "Conteúdo e Ensaio Fotográfico",
  produtos: "Produtos Novos",
  marketing: "Marketing e Campanhas",
  "press-kit": "Press-kit",
};

export const AREA_COLORS: Record<Area, string> = {
  nuvemshop: "#6366f1",
  carnaval: "#f59e0b",
  orochi: "#ef4444",
  nation: "#10b981",
  "carlos-prates": "#8b5cf6",
  comercial: "#3b82f6",
  "kit-pdv": "#ec4899",
  "garrafa-nova": "#14b8a6",
  rtd: "#f97316",
  conteudo: "#06b6d4",
  produtos: "#84cc16",
  marketing: "#e879f9",
  "press-kit": "#a78bfa",
};

export const PRIORITY_COLORS: Record<Priority, string> = {
  alta: "#ef4444",
  media: "#f59e0b",
  baixa: "#6b7280",
};

export const STATUS_COLORS: Record<Status, string> = {
  pendente: "#6b7280",
  "em-andamento": "#3b82f6",
  concluida: "#10b981",
  atrasada: "#ef4444",
};

export const STATUS_LABELS: Record<Status, string> = {
  pendente: "Pendente",
  "em-andamento": "Em andamento",
  concluida: "Concluída",
  atrasada: "Atrasada",
};

export const DECISIONS: Decision[] = [
  { id: "D1", title: "Kit Carnaval: 3 garrafas mistas a R$299 (+5% crédito)", context: "Preço definido na hora por João. Luca faz criativos." },
  { id: "D2", title: "Migração Nuvemshop é prioridade máxima", context: "Integração WooCommerce/Bling está causando problemas recorrentes." },
  { id: "D3", title: "Nation lança ANTES do Orochi (soft launch início de Março)", context: "O Nation precisa estar ativo para que já existam revendedores quando a Garrafa Orochi for lançada (Abril-Maio). Não são simultâneos — o Nation potencializa o Orochi." },
  { id: "D4", title: "Nation antes do Delivery", context: "Início de Março para Nation, final de Março para Delivery." },
  { id: "D5", title: "Não contratar vendedor agora", context: "Primeiro estruturar processos e CRM. Contratar sem processo gera caos." },
  { id: "D6", title: "Press-kits entregues em mãos no Rio", context: "Maior poder de conversão. João envia, Luhan/MD entregam." },
  { id: "D7", title: "Fotos no Rio, vídeos em BH", context: "Aproveitar presença do MD no Rio. BH é mais barato para vídeo." },
  { id: "D8", title: "RTD: validar em BH, lançar em Dezembro", context: "BH é o mercado mais exigente. Validar antes de escalar." },
  { id: "D9", title: "Rebranding vem com a garrafa nova", context: "Não faz sentido discutir logo separadamente. Tudo junto." },
  { id: "D10", title: "Vendas PJ pequenas vão para o site", context: "Pedro foca em PJ. Compras de 1-2 garrafas são direcionadas ao e-commerce." },
];

export const DEPENDENCY_MAP: Dependency[] = [
  { from: "Nuvemshop", to: "Mr. Lion Nation", label: "Nation depende da loja estar operacional" },
  { from: "Nuvemshop", to: "AfiliaTrack", label: "Programa de afiliados é app nativo da Nuvemshop" },
  { from: "Kit PDV", to: "Estruturação Comercial", label: "Kit depende de processos definidos" },
  { from: "Garrafa Nova", to: "Press-kit", label: "Press-kit deve refletir nova identidade" },
  { from: "Processos/CRM", to: "Contratação Vendedor", label: "Primeiro processos, depois pessoas" },
];

export const TIMELINE_PERIODS = [
  { id: "imediato", label: "13-20/02", title: "Imediato", color: "#ef4444" },
  { id: "curto", label: "20-28/02", title: "Curto Prazo", color: "#f59e0b" },
  { id: "marco-inicio", label: "Mar (início)", title: "Março Início", color: "#3b82f6" },
  { id: "marco-final", label: "Mar (final)", title: "Março Final", color: "#6366f1" },
  { id: "abril-maio", label: "Abr-Mai", title: "Abril-Maio", color: "#8b5cf6" },
  { id: "junho-julho", label: "Jun-Jul", title: "Junho-Julho", color: "#10b981" },
  { id: "agosto-outubro", label: "Ago-Out", title: "Agosto-Outubro", color: "#14b8a6" },
  { id: "novembro-dezembro", label: "Nov-Dez", title: "Novembro-Dezembro", color: "#f97316" },
];

export const DEFAULT_TASKS: Task[] = [
  {
    id: 1,
    title: "Avaliar gateways de pagamento",
    detail: "João questionou a taxa alta do Mercado Pago. Avaliar Nuvem Pago (taxa menor, mas sem proteção contra cartão clonado) e outras opções. Luca enviará PDF comparativo.",
    responsible: ["João"],
    priority: "alta",
    area: "nuvemshop",
    status: "pendente",
    dependencies: [],
    notes: "",
    decision: "D2",
  },
  {
    id: 2,
    title: "Resolver questão do CNPJ",
    detail: "Sem o CNPJ resolvido, João não consegue avançar com o site. Luhan vai ligar para o MD junto com João hoje mesmo para acelerar.",
    responsible: ["Luhan", "João"],
    priority: "alta",
    area: "nuvemshop",
    status: "pendente",
    dependencies: [],
    notes: "",
    decision: "D2",
  },
  {
    id: 3,
    title: "Testar bot de suporte Nuvemshop",
    detail: "Bot já configurado na Nuvemshop, mas nunca testado. Precisa validar antes de ativar.",
    responsible: ["Luca"],
    priority: "alta",
    area: "nuvemshop",
    status: "pendente",
    dependencies: [],
    notes: "",
    decision: null,
  },
  {
    id: 4,
    title: "Testar integração Bling + Nuvemshop (pedidos, status, baixa de estoque)",
    detail: "Bling já integrado, mas precisa de testes. Verificar se puxa pedidos corretamente, se o status é atualizado e se a baixa de estoque funciona. Melhor Envio é tarefa separada (#35).",
    responsible: ["Luca"],
    priority: "alta",
    area: "nuvemshop",
    status: "pendente",
    dependencies: [],
    notes: "",
    decision: "D2",
  },
  {
    id: 5,
    title: "Avaliar questão dos kits/combos na Nuvemshop",
    detail: "Na Nuvemshop, kits precisam ser cadastrados como produto único (não como itens separados). Isso já deu problema com o Bling no passado. Precisa testar antes de subir. Inclui avaliar o comportamento do frete quando o cliente compra múltiplas unidades (ver também tarefa #38).",
    responsible: ["João", "Luca"],
    priority: "alta",
    area: "nuvemshop",
    status: "pendente",
    dependencies: [4],
    notes: "",
    decision: "D2",
  },
  {
    id: 6,
    title: "Configurar domínio Nuvemshop",
    detail: "Só será feito após o gateway estar resolvido, para não derrubar o site atual.",
    responsible: ["Luca"],
    priority: "alta",
    area: "nuvemshop",
    status: "pendente",
    dependencies: [1],
    notes: "",
    decision: "D2",
  },
  {
    id: 7,
    title: "Kit Carnaval — 3 garrafas a R$299",
    detail: "3 garrafas mistas por R$299 (+ 5% no crédito). Preço definido na reunião por João.",
    responsible: ["João", "Luca"],
    priority: "alta",
    area: "carnaval",
    status: "pendente",
    dependencies: [],
    notes: "",
    decision: "D1",
  },
  {
    id: 8,
    title: "Criativos e Stories de Carnaval",
    detail: "Luca fará criativos para Stories orgânicos durante o Carnaval e deixará rodando no tráfego pago.",
    responsible: ["Luca"],
    priority: "alta",
    area: "carnaval",
    status: "pendente",
    dependencies: [],
    notes: "",
    decision: "D1",
  },
  {
    id: 9,
    title: "Enviar press-kits para o Rio",
    detail: "João vai enviar os kits. Não precisa esperar os cartões impressos.",
    responsible: ["João"],
    priority: "media",
    area: "press-kit",
    status: "pendente",
    dependencies: [],
    notes: "",
    decision: "D6",
  },
  {
    id: 10,
    title: "Imprimir material gráfico no Rio",
    detail: "Luhan recebe o material e manda imprimir em gráfica local para manter o padrão.",
    responsible: ["Luhan"],
    priority: "media",
    area: "press-kit",
    status: "pendente",
    dependencies: [9],
    notes: "",
    decision: "D6",
  },
  {
    id: 11,
    title: "Enviar amostras para Orochi",
    detail: "Já foram despachadas. Aguardando chegada no Rio.",
    responsible: ["João"],
    priority: "alta",
    area: "orochi",
    status: "concluida",
    dependencies: [],
    notes: "",
    decision: null,
  },
  {
    id: 12,
    title: "Levar amostras ao Orochi pessoalmente",
    detail: "Assim que chegar, é prioridade levar pessoalmente. Orochi é imprevisível — pode marcar hoje e ser amanhã. Ter jogo de cintura.",
    responsible: ["Luhan"],
    priority: "alta",
    area: "orochi",
    status: "pendente",
    dependencies: [11],
    notes: "",
    decision: null,
  },
  {
    id: 13,
    title: "Enviar apresentação da marca no grupo",
    detail: "Luca vai reenviar a apresentação da marca (12 páginas) no grupo para Luhan avaliar.",
    responsible: ["Luca"],
    priority: "media",
    area: "orochi",
    status: "pendente",
    dependencies: [],
    notes: "",
    decision: null,
  },
  {
    id: 14,
    title: "Luhan avaliar apresentação e sugerir ajustes",
    detail: "Luhan avalia se está no caminho certo e sugere ajustes antes de mostrar ao Orochi.",
    responsible: ["Luhan"],
    priority: "media",
    area: "orochi",
    status: "pendente",
    dependencies: [13],
    notes: "",
    decision: null,
  },
  {
    id: 15,
    title: "Estruturar programa Mr. Lion Nation (treinamento)",
    detail: "João vai montar o conteúdo vídeo a vídeo. Ideia: vídeos pontuais, bem editados, sem enrolação. Um do Vamp (vendas) e um do MD (marca).",
    responsible: ["João"],
    priority: "alta",
    area: "nation",
    status: "pendente",
    dependencies: [],
    notes: "",
    decision: "D3",
  },
  {
    id: 16,
    title: "Definir premiações e ranking do Nation",
    detail: "Premiação final de ~R$30.000 + ranking mensal com prêmios menores (iPhone, quadros, etc.). Sistema de pontos acumulados com opções de prêmio. João vai montar a proposta e bater com o time.",
    responsible: ["João"],
    priority: "alta",
    area: "nation",
    status: "pendente",
    dependencies: [],
    notes: "",
    decision: "D3",
  },
  {
    id: 17,
    title: "Estratégia de aproximação Carlos Prates",
    detail: "MD precisa ir à casa dele em SP, passar 1-2 dias, construir relacionamento. Não é uma negociação — é uma construção.",
    responsible: ["Luhan"],
    priority: "media",
    area: "carlos-prates",
    status: "pendente",
    dependencies: [],
    notes: "",
    decision: null,
  },
  {
    id: 18,
    title: "Tentar visita ao Carlos Prates em SP (~5 de Março)",
    detail: "João estará em SP por volta de 5 de Março. MD tem show dias 6-7 e compromisso dia 8. Tentar alinhar uma data.",
    responsible: ["João", "Luhan"],
    priority: "media",
    area: "carlos-prates",
    status: "pendente",
    dependencies: [],
    notes: "",
    decision: null,
  },
  {
    id: 19,
    title: "Enviar amostras para Carlos Prates",
    detail: "Luhan pode adiantar enviando amostras para Carlos Prates em Fevereiro, antes da visita presencial.",
    responsible: ["Luhan"],
    priority: "media",
    area: "carlos-prates",
    status: "pendente",
    dependencies: [],
    notes: "",
    decision: null,
  },
  {
    id: 20,
    title: "Confirmar cobrança por mensagem no HighLevel",
    detail: "Luca precisa confirmar se o HighLevel cobra por mensagem enviada (início de conversa) ou por todas as mensagens. Impacta a decisão sobre o bot SDR.",
    responsible: ["Luca"],
    priority: "media",
    area: "comercial",
    status: "pendente",
    dependencies: [],
    notes: "",
    decision: null,
  },
  {
    id: 21,
    title: "Trocar ideia com contato do João (bot SDR)",
    detail: "João tem um contato que faz bots SDR. Trocar uma ideia para avaliar se terceiriza ou continua no HighLevel.",
    responsible: ["João"],
    priority: "media",
    area: "comercial",
    status: "pendente",
    dependencies: [],
    notes: "",
    decision: null,
  },
  {
    id: 22,
    title: "Marcar reunião com Vinícius (processos)",
    detail: "Luhan vai ligar hoje para o Vinícius e marcar uma reunião para introduzir o Luca e discutir processos que precisam ser estruturados. Vinícius pode ser a pessoa para executar e potencializar as ideias.",
    responsible: ["Luhan"],
    priority: "alta",
    area: "comercial",
    status: "pendente",
    dependencies: [],
    notes: "",
    decision: "D5",
  },
  {
    id: 23,
    title: "Pedro — Documento diagnóstico comercial",
    detail: "Pedro vai documentar: como está o processo, o que tem testado, o que está dando certo, o que está dando errado, padrões observados no tráfego, dúvidas recorrentes dos leads. Documento simples, visão geral.",
    responsible: ["Pedro"],
    priority: "alta",
    area: "comercial",
    status: "pendente",
    dependencies: [],
    notes: "",
    decision: "D5",
  },
  {
    id: 24,
    title: "Pedro — Mensagem padrão de pré-cadastro PJ",
    detail: "Pedro já começou a montar uma mensagem de pré-cadastro para coletar dados do lead PJ na conversa inicial (endereço, CNPJ, etc.). Continuar e padronizar.",
    responsible: ["Pedro"],
    priority: "media",
    area: "comercial",
    status: "pendente",
    dependencies: [],
    notes: "",
    decision: "D10",
  },
  {
    id: 25,
    title: "Atualizar documento Kit PDV com novas ideias",
    detail: "Incorporar as novas sugestões: logo luminosa (Guilherme), totem tamanho real do MD (simplificado no início, madeira depois para quem vende bem), placa de madeira iluminada (Pedro vai enviar referência). Organizar por níveis de compra conforme tabela do João.",
    responsible: ["Luca", "Guilherme"],
    priority: "media",
    area: "kit-pdv",
    status: "pendente",
    dependencies: [26],
    notes: "",
    decision: null,
  },
  {
    id: 26,
    title: "Pedro — Enviar referência de placa de madeira",
    detail: "Pedro viu numa destilaria e vai procurar imagem e material para compartilhar no grupo.",
    responsible: ["Pedro"],
    priority: "baixa",
    area: "kit-pdv",
    status: "pendente",
    dependencies: [],
    notes: "",
    decision: null,
  },
  {
    id: 27,
    title: "Garrafa nova + Rebranding",
    detail: "Luca vai desenvolver após resolver as questões básicas (Nuvemshop, integração, atendimento). O rebranding vem junto com a garrafa — não faz sentido discutir logo separadamente. Guilherme reforçou: padronizar um leão único para a marca.",
    responsible: ["Luca"],
    priority: "media",
    area: "garrafa-nova",
    status: "pendente",
    dependencies: [1, 4, 6],
    notes: "",
    decision: "D9",
  },
  {
    id: 28,
    title: "RTD — Definir sabor e começar composição",
    detail: "Começar a definir agora. Guilherme pesquisou: marcas validam primeiro em BH (mercado mais exigente). Lançamento final em Dezembro para pegar verão + Carnaval. Validação em BH em Outubro.",
    responsible: ["João", "Guilherme"],
    priority: "media",
    area: "rtd",
    status: "pendente",
    dependencies: [],
    notes: "",
    decision: "D8",
  },
  {
    id: 29,
    title: "RTD — Enviar amostras para MD",
    detail: "Começar a enviar amostras para o MD ir provando e dando feedback.",
    responsible: ["João"],
    priority: "media",
    area: "rtd",
    status: "pendente",
    dependencies: [28],
    notes: "",
    decision: "D8",
  },
  {
    id: 30,
    title: "Luhan — Orçamento de ensaio fotográfico no Rio",
    detail: "Fotos de produto (glorify) com elementos visuais de whisky. Fotos do Cappuccino, Black Harley e Blended são ruins — só o Honey tem foto boa. Vídeos podem ser feitos em BH (mais barato). Fotos no Rio para já aproveitar com MD.",
    responsible: ["Luhan"],
    priority: "alta",
    area: "conteudo",
    status: "pendente",
    dependencies: [],
    notes: "",
    decision: "D7",
  },
  {
    id: 31,
    title: "João — Pesquisar fornecedor de copos",
    detail: "Demanda reprimida — clientes sempre perguntam por copos. Nem que seja um copinho simples para começar.",
    responsible: ["João"],
    priority: "media",
    area: "produtos",
    status: "pendente",
    dependencies: [],
    notes: "",
    decision: null,
  },
  {
    id: 32,
    title: "João — Pesquisar garrafa 375ml e kit de 3",
    detail: "Kit de 3 garrafas de 375ml para presente. Guilherme sugeriu caixa com alça. João vai olhar com André. Precisa de arte e dimensões do time de design.",
    responsible: ["João"],
    priority: "media",
    area: "produtos",
    status: "pendente",
    dependencies: [],
    notes: "",
    decision: null,
  },
  {
    id: 33,
    title: "Compartilhar link do painel de reunião no grupo",
    detail: "Luca vai compartilhar o link do painel interativo da reunião no grupo do WhatsApp para todos ficarem cientes.",
    responsible: ["Luca"],
    priority: "baixa",
    area: "comercial",
    status: "pendente",
    dependencies: [],
    notes: "",
    decision: null,
  },
  {
    id: 34,
    title: "Avaliar funil de leads na Nuvemshop (visitante vs. carrinho)",
    detail: "Luhan perguntou se é possível separar quem só visitou o site de quem foi até o carrinho, para qualificar leads frios vs. quentes. Luca disse que acha possível mas não avaliou ainda. Impacta diretamente a eficiência do tráfego pago.",
    responsible: ["Luca"],
    priority: "media",
    area: "nuvemshop",
    status: "pendente",
    dependencies: [],
    notes: "",
    decision: null,
  },
  {
    id: 35,
    title: "Testar integração Melhor Envio / Nuvem Envio na Nuvemshop",
    detail: "Melhor Envio já instalado mas nunca testado. Nuvem Envio também habilitado e parece boa opção. Integração separada do Bling (#04).",
    responsible: ["Luca"],
    priority: "alta",
    area: "nuvemshop",
    status: "pendente",
    dependencies: [],
    notes: "",
    decision: null,
  },
  {
    id: 36,
    title: "Planejar ação presencial RTD na Copa (latinhas + QR Code)",
    detail: "Guilherme propôs distribuir 1.000-5.000 latinhas presencialmente durante a Copa, com cadastro no site via QR Code (pessoa ganha latinha grátis se se cadastrar na Nuvemshop). Luhan confirmou que já fez ações similares com música e que funciona. Logística: produção de latinhas de teste, QR codes, equipe de rua, definição de local.",
    responsible: ["Guilherme", "João"],
    priority: "media",
    area: "rtd",
    status: "pendente",
    dependencies: [28],
    notes: "",
    decision: "D8",
  },
  {
    id: 37,
    title: "Sondar a Toy sobre campanha Dia da Mulher (8/03)",
    detail: "Luhan sugeriu a Toy como embaixadora/cara da campanha de Dia da Mulher. João concordou (\"faz sentido com ela\"). Luhan se ofereceu para sondar. Não é contratação ainda — é uma sondagem de disponibilidade e interesse. 8 de Março está próximo.",
    responsible: ["Luhan"],
    priority: "alta",
    area: "marketing",
    status: "pendente",
    dependencies: [],
    notes: "",
    decision: null,
  },
  {
    id: 38,
    title: "Testar cálculo de frete para múltiplas unidades e caixas 2/3",
    detail: "O frete bugava no site antigo quando o cliente comprava mais de uma unidade ou kits. João disse \"a gente olha isso bem antes de subir\". Bug crítico de conversão que merece atenção separada da tarefa #05.",
    responsible: ["João", "Luca"],
    priority: "alta",
    area: "nuvemshop",
    status: "pendente",
    dependencies: [],
    notes: "",
    decision: "D2",
  },
  {
    id: 39,
    title: "Avaliar relançamento do Black Honey durante a Copa",
    detail: "Guilherme identificou demanda reprimida e sugeriu relançar durante a Copa. João considerou a ideia. Não é só uma sugestão — é uma oportunidade concreta com demanda já mapeada pelo time. Avaliar viabilidade de produção e timing.",
    responsible: ["João", "Guilherme"],
    priority: "media",
    area: "produtos",
    status: "pendente",
    dependencies: [],
    notes: "",
    decision: null,
  },
];

// Helper: get timeline period for a task (area-based grouping)
export function getTimelinePeriod(task: Task): string {
  const areaMap: Record<string, string> = {
    "nuvemshop": "imediato",
    "carnaval": "imediato",
    "conteudo": "curto",
    "marketing": "curto",
    "comercial": "curto",
    "kit-pdv": "marco-inicio",
    "press-kit": "marco-inicio",
    "nation": "marco-inicio",
    "orochi": "abril-maio",
    "carlos-prates": "abril-maio",
    "garrafa-nova": "junho-julho",
    "rtd": "agosto-outubro",
    "produtos": "marco-final",
  };
  return areaMap[task.area] || "marco-final";
}

// Helper: get tasks for a specific team member
export function getTasksForMember(tasks: Task[], member: string): Task[] {
  return tasks.filter((t) => t.responsible.some((r) => r === member));
}

// Helper: get tasks for a specific area
export function getTasksForArea(tasks: Task[], area: Area): Task[] {
  return tasks.filter((t) => t.area === area);
}
