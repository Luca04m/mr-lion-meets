export function formatTime(totalSeconds: number): string {
  const h = Math.floor(totalSeconds / 3600);
  const m = Math.floor((totalSeconds % 3600) / 60);
  const s = totalSeconds % 60;
  if (h > 0) {
    return `${h}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
  }
  return `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
}

export function getTimerClass(elapsedSeconds: number, budgetMinutes: number): string {
  const ratio = elapsedSeconds / (budgetMinutes * 60);
  if (ratio >= 1) return "timer-danger";
  if (ratio >= 0.75) return "timer-warning";
  return "";
}

export function getProgressColor(elapsedSeconds: number, budgetMinutes: number): string {
  const ratio = elapsedSeconds / (budgetMinutes * 60);
  if (ratio >= 1) return "var(--color-phase-red)";
  if (ratio >= 0.75) return "var(--color-phase-yellow)";
  return "var(--color-gold)";
}
