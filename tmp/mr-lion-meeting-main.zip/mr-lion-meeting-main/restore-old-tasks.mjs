import mysql from 'mysql2/promise';
import { config } from 'dotenv';
config();

const conn = await mysql.createConnection(process.env.DATABASE_URL);

// These are the original 39 tasks from the 13/02 meeting with their original statuses
const oldTasks = [
  { title: "Avaliar gateways de pagamento", detail: "João questionou a taxa alta do Mercado Pago. Avaliar Nuvem Pago (taxa menor, mas sem proteção contra cartão clonado) e outras opções.", responsible: ["João"], priority: "alta", area: "nuvemshop", status: "pendente" },
  { title: "Resolver questão do CNPJ", detail: "Sem o CNPJ resolvido, João não consegue avançar com o site. Luhan vai ligar para o MD junto com João.", responsible: ["Luhan", "João"], priority: "alta", area: "nuvemshop", status: "pendente" },
  { title: "Testar bot de suporte Nuvemshop", detail: "Bot já configurado na Nuvemshop, mas nunca testado. Precisa validar antes de ativar.", responsible: ["Luca"], priority: "alta", area: "nuvemshop", status: "pendente" },
  { title: "Testar integração Bling + Nuvemshop", detail: "Bling já integrado, mas precisa de testes. Verificar se puxa pedidos corretamente.", responsible: ["Luca"], priority: "alta", area: "nuvemshop", status: "pendente" },
  { title: "Avaliar questão dos kits/combos na Nuvemshop", detail: "Na Nuvemshop, kits precisam ser cadastrados como produto único. Precisa testar antes de subir.", responsible: ["João", "Luca"], priority: "alta", area: "nuvemshop", status: "pendente" },
  { title: "Configurar domínio Nuvemshop", detail: "Só será feito após o gateway estar resolvido, para não derrubar o site atual.", responsible: ["Luca"], priority: "alta", area: "nuvemshop", status: "pendente" },
  { title: "Kit Carnaval — 3 garrafas a R$299", detail: "3 garrafas mistas por R$299 (+ 5% no crédito). Preço definido na reunião por João.", responsible: ["João", "Luca"], priority: "alta", area: "carnaval", status: "pendente" },
  { title: "Criativos e Stories de Carnaval", detail: "Luca fará criativos para Stories orgânicos durante o Carnaval e deixará rodando no tráfego pago.", responsible: ["Luca"], priority: "alta", area: "carnaval", status: "pendente" },
  { title: "Enviar press-kits para o Rio", detail: "João vai enviar os kits. Não precisa esperar os cartões impressos.", responsible: ["João"], priority: "media", area: "press-kit", status: "pendente" },
  { title: "Imprimir material gráfico no Rio", detail: "Luhan recebe o material e manda imprimir em gráfica local para manter o padrão.", responsible: ["Luhan"], priority: "media", area: "press-kit", status: "pendente" },
  { title: "Enviar amostras para Orochi", detail: "Já foram despachadas. Aguardando chegada no Rio.", responsible: ["João"], priority: "alta", area: "orochi", status: "concluida" },
  { title: "Levar amostras ao Orochi pessoalmente", detail: "Assim que chegar, é prioridade levar pessoalmente.", responsible: ["Luhan"], priority: "alta", area: "orochi", status: "pendente" },
  { title: "Enviar apresentação da marca no grupo", detail: "Luca vai reenviar a apresentação da marca (12 páginas) no grupo para Luhan avaliar.", responsible: ["Luca"], priority: "media", area: "orochi", status: "pendente" },
  { title: "Luhan avaliar apresentação e sugerir ajustes", detail: "Luhan avalia se está no caminho certo e sugere ajustes antes de mostrar ao Orochi.", responsible: ["Luhan"], priority: "media", area: "orochi", status: "pendente" },
  { title: "Estruturar programa Mr. Lion Nation (treinamento)", detail: "João vai montar o conteúdo vídeo a vídeo. Vídeos pontuais, bem editados, sem enrolação.", responsible: ["João"], priority: "alta", area: "nation", status: "pendente" },
  { title: "Definir premiações e ranking do Nation", detail: "Premiação final de ~R$30.000 + ranking mensal com prêmios menores. Sistema de pontos acumulados.", responsible: ["João"], priority: "alta", area: "nation", status: "pendente" },
  { title: "Estratégia de aproximação Carlos Prates", detail: "MD precisa ir à casa dele em SP, passar 1-2 dias, construir relacionamento.", responsible: ["Luhan"], priority: "media", area: "carlos-prates", status: "pendente" },
  { title: "Tentar visita ao Carlos Prates em SP (~5 de Março)", detail: "João estará em SP por volta de 5 de Março. Tentar alinhar uma data.", responsible: ["João", "Luhan"], priority: "media", area: "carlos-prates", status: "pendente" },
  { title: "Enviar amostras para Carlos Prates", detail: "Luhan pode adiantar enviando amostras para Carlos Prates em Fevereiro.", responsible: ["Luhan"], priority: "media", area: "carlos-prates", status: "pendente" },
  { title: "Confirmar cobrança por mensagem no HighLevel", detail: "Luca precisa confirmar se o HighLevel cobra por mensagem enviada ou por todas as mensagens.", responsible: ["Luca"], priority: "media", area: "comercial", status: "pendente" },
  { title: "Trocar ideia com contato do João (bot SDR)", detail: "João tem um contato que faz bots SDR. Avaliar se terceiriza ou continua no HighLevel.", responsible: ["João"], priority: "media", area: "comercial", status: "pendente" },
  { title: "Marcar reunião com Vinícius (processos)", detail: "Luhan vai ligar para o Vinícius e marcar uma reunião para introduzir o Luca e discutir processos.", responsible: ["Luhan"], priority: "alta", area: "comercial", status: "pendente" },
  { title: "Pedro — Documento diagnóstico comercial", detail: "Pedro vai documentar: como está o processo, o que tem testado, o que está dando certo/errado.", responsible: ["Pedro"], priority: "alta", area: "comercial", status: "pendente" },
  { title: "Pedro — Mensagem padrão de pré-cadastro PJ", detail: "Pedro já começou a montar uma mensagem de pré-cadastro para coletar dados do lead PJ.", responsible: ["Pedro"], priority: "media", area: "comercial", status: "pendente" },
  { title: "Atualizar documento Kit PDV com novas ideias", detail: "Incorporar novas sugestões: logo luminosa, totem tamanho real do MD, placa de madeira iluminada.", responsible: ["Luca", "Guilherme"], priority: "media", area: "kit-pdv", status: "pendente" },
  { title: "Pedro — Enviar referência de placa de madeira", detail: "Pedro viu numa destilaria e vai procurar imagem e material para compartilhar no grupo.", responsible: ["Pedro"], priority: "baixa", area: "kit-pdv", status: "pendente" },
  { title: "Garrafa nova + Rebranding", detail: "Luca vai desenvolver após resolver as questões básicas. O rebranding vem junto com a garrafa.", responsible: ["Luca"], priority: "media", area: "garrafa-nova", status: "pendente" },
  { title: "RTD — Definir sabor e começar composição", detail: "Validação em BH em Outubro. Lançamento final em Dezembro para pegar verão + Carnaval.", responsible: ["João", "Guilherme"], priority: "media", area: "rtd", status: "pendente" },
  { title: "RTD — Enviar amostras para MD", detail: "Começar a enviar amostras para o MD ir provando e dando feedback.", responsible: ["João"], priority: "media", area: "rtd", status: "pendente" },
  { title: "Luhan — Orçamento de ensaio fotográfico no Rio", detail: "Fotos de produto com elementos visuais de whisky. Fotos no Rio para aproveitar com MD.", responsible: ["Luhan"], priority: "alta", area: "conteudo", status: "pendente" },
  { title: "João — Pesquisar fornecedor de copos", detail: "Demanda reprimida — clientes sempre perguntam por copos.", responsible: ["João"], priority: "media", area: "produtos", status: "pendente" },
  { title: "João — Pesquisar garrafa 375ml e kit de 3", detail: "Kit de 3 garrafas de 375ml para presente. Guilherme sugeriu caixa com alça.", responsible: ["João"], priority: "media", area: "produtos", status: "pendente" },
  { title: "Compartilhar link do painel de reunião no grupo", detail: "Luca vai compartilhar o link do painel interativo da reunião no grupo do WhatsApp.", responsible: ["Luca"], priority: "baixa", area: "comercial", status: "pendente" },
  { title: "Avaliar funil de leads na Nuvemshop", detail: "Separar quem só visitou o site de quem foi até o carrinho, para qualificar leads frios vs. quentes.", responsible: ["Luca"], priority: "media", area: "nuvemshop", status: "pendente" },
  { title: "Testar integração Melhor Envio / Nuvem Envio", detail: "Melhor Envio já instalado mas nunca testado. Nuvem Envio também habilitado.", responsible: ["Luca"], priority: "alta", area: "nuvemshop", status: "pendente" },
  { title: "Planejar ação presencial RTD na Copa", detail: "Distribuir 1.000-5.000 latinhas presencialmente durante a Copa, com cadastro via QR Code.", responsible: ["Guilherme", "João"], priority: "media", area: "rtd", status: "pendente" },
  { title: "Sondar a Toy sobre campanha Dia da Mulher (8/03)", detail: "Luhan sugeriu a Toy como embaixadora/cara da campanha de Dia da Mulher.", responsible: ["Luhan"], priority: "alta", area: "marketing", status: "pendente" },
  { title: "Testar cálculo de frete para múltiplas unidades", detail: "O frete bugava no site antigo quando o cliente comprava mais de uma unidade ou kits.", responsible: ["João", "Luca"], priority: "alta", area: "nuvemshop", status: "pendente" },
  { title: "Avaliar relançamento do Black Honey durante a Copa", detail: "Guilherme identificou demanda reprimida e sugeriu relançar durante a Copa.", responsible: ["João", "Guilherme"], priority: "media", area: "produtos", status: "pendente" },
];

let count = 0;
for (const t of oldTasks) {
  await conn.execute(
    `INSERT INTO tasks (title, detail, responsible, priority, area, status, notes, isOriginal)
     VALUES (?, ?, ?, ?, ?, ?, '', 1)`,
    [t.title, t.detail, JSON.stringify(t.responsible), t.priority, t.area, t.status]
  );
  count++;
  console.log(`✓ ${count}. ${t.title}`);
}

console.log(`\n✓ ${count} tarefas da reunião 13/02 restauradas.`);
await conn.end();
