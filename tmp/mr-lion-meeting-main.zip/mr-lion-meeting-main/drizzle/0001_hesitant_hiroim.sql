CREATE TABLE `activity_log` (
	`id` int AUTO_INCREMENT NOT NULL,
	`taskId` int NOT NULL,
	`taskTitle` varchar(500) DEFAULT '',
	`userName` varchar(100) NOT NULL,
	`action` varchar(50) NOT NULL,
	`oldValue` text,
	`newValue` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `activity_log_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `tasks` (
	`id` int AUTO_INCREMENT NOT NULL,
	`title` varchar(500) NOT NULL,
	`detail` text DEFAULT (''),
	`responsible` json NOT NULL,
	`deadline` varchar(200) DEFAULT '',
	`deadlineDate` varchar(20),
	`priority` enum('alta','media','baixa') NOT NULL DEFAULT 'media',
	`area` varchar(50) NOT NULL,
	`status` enum('pendente','em-andamento','concluida','atrasada') NOT NULL DEFAULT 'pendente',
	`dependencies` json DEFAULT ('[]'),
	`notes` text DEFAULT (''),
	`decision` varchar(10),
	`createdBy` varchar(100) DEFAULT 'Sistema',
	`isOriginal` int DEFAULT 1,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `tasks_id` PRIMARY KEY(`id`)
);
