CREATE TABLE `meetings` (
	`id` int AUTO_INCREMENT NOT NULL,
	`title` varchar(500) NOT NULL,
	`meetingDate` varchar(20) NOT NULL,
	`fileType` enum('pauta','resumo','outro') NOT NULL DEFAULT 'pauta',
	`fileName` varchar(500) NOT NULL,
	`fileUrl` text NOT NULL,
	`fileKey` varchar(500) NOT NULL,
	`uploadedBy` varchar(100) DEFAULT 'Sistema',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `meetings_id` PRIMARY KEY(`id`)
);
