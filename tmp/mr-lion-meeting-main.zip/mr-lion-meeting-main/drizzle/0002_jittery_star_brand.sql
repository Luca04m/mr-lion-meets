ALTER TABLE `activity_log` MODIFY COLUMN `taskTitle` varchar(500);--> statement-breakpoint
ALTER TABLE `tasks` MODIFY COLUMN `detail` text;--> statement-breakpoint
ALTER TABLE `tasks` MODIFY COLUMN `deadline` varchar(200);--> statement-breakpoint
ALTER TABLE `tasks` MODIFY COLUMN `dependencies` json;--> statement-breakpoint
ALTER TABLE `tasks` MODIFY COLUMN `notes` text;