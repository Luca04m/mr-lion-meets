import { int, json, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Tasks table — collaborative task management
 */
export const tasks = mysqlTable("tasks", {
  id: int("id").autoincrement().primaryKey(),
  title: varchar("title", { length: 500 }).notNull(),
  detail: text("detail"),
  responsible: json("responsible").$type<string[]>().notNull(),
  deadline: varchar("deadline", { length: 200 }),
  deadlineDate: varchar("deadlineDate", { length: 20 }),
  priority: mysqlEnum("priority", ["alta", "media", "baixa"]).default("media").notNull(),
  area: varchar("area", { length: 50 }).notNull(),
  status: mysqlEnum("status", ["pendente", "em-andamento", "concluida", "atrasada"]).default("pendente").notNull(),
  dependencies: json("dependencies").$type<number[]>(),
  notes: text("notes"),
  decision: varchar("decision", { length: 10 }),
  createdBy: varchar("createdBy", { length: 100 }).default("Sistema"),
  isOriginal: int("isOriginal").default(1),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type TaskRow = typeof tasks.$inferSelect;
export type InsertTask = typeof tasks.$inferInsert;

/**
 * Activity log — audit trail for all task changes
 */
export const activityLog = mysqlTable("activity_log", {
  id: int("id").autoincrement().primaryKey(),
  taskId: int("taskId").notNull(),
  taskTitle: varchar("taskTitle", { length: 500 }),
  userName: varchar("userName", { length: 100 }).notNull(),
  action: varchar("action", { length: 50 }).notNull(),
  oldValue: text("oldValue"),
  newValue: text("newValue"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ActivityLog = typeof activityLog.$inferSelect;
export type InsertActivityLog = typeof activityLog.$inferInsert;

/**
 * Meetings table — uploaded meeting agendas and summaries
 */
export const meetings = mysqlTable("meetings", {
  id: int("id").autoincrement().primaryKey(),
  title: varchar("title", { length: 500 }).notNull(),
  meetingDate: varchar("meetingDate", { length: 20 }).notNull(),
  fileType: mysqlEnum("fileType", ["pauta", "resumo", "outro"]).default("pauta").notNull(),
  fileName: varchar("fileName", { length: 500 }).notNull(),
  fileUrl: text("fileUrl").notNull(),
  fileKey: varchar("fileKey", { length: 500 }).notNull(),
  uploadedBy: varchar("uploadedBy", { length: 100 }).default("Sistema"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type MeetingRow = typeof meetings.$inferSelect;
export type InsertMeeting = typeof meetings.$inferInsert;
